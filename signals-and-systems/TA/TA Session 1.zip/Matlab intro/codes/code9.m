vec1 = 0:1:9;

vec2 = [4 8];

disp(vec1(vec2));
