x = [1 2 3 4; 1 2 3 4];

% disp(sum(x,2))

disp(max(x,[],2))


