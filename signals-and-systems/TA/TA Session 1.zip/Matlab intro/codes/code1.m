text = 'helloooo world!';
disp(text);