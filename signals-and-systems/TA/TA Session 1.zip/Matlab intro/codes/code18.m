f0 = @(x,y) x.^2+y.^2;
f1 = @(x) sqrt(x);

disp(f1(f0(3,4)))