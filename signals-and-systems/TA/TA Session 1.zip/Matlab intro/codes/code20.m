f0 = @(x,f1) f1(x)+5;
f2 = @(x) x.^2;

disp(f0(5,f2));
