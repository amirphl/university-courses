a = 5;
b = 4;

c = a+b;
disp(c);

clear a b;