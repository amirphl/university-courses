function [outputArg1,outputArg2] = f3(inputArg1)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = inputArg1+1;
outputArg2 = inputArg1+2;
end

