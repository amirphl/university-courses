function [outputArg1] = f2(inputArg1)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = inputArg1 + 1;
end

