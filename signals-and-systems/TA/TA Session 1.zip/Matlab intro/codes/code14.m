i = 5;

if(i<0)
    disp('negative');

elseif (i==0)
    disp('negative');

else
    disp('positive');
end
