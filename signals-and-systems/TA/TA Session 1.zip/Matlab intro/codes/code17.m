tic

while(toc<5)
    disp('hi');
end
