% x = [1 2 3 4 ; 1 2 3 4];
% 
% y = 1:1:10;
% 
% z = 0:0.01:10;
% 
% disp(size(z));
% 
% [r c] = size(z);

  randomMatrix = rand(6,8);
 
  disp(size(randomMatrix));

