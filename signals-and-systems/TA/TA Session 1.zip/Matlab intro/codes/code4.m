x = rand(1,1);
disp(x);
% m x n random matrix between 0 and 1

y = randi(5);
disp(y);
%between 1 and 5

z = randi([2 10]);
disp(z);
%between 2 and 10