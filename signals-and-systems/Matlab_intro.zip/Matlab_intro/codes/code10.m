x = rand(2, 3, 5, 2);

disp(size(x));

disp(length(x));

disp(length(size(x)));
%returns size of the largest dimension
