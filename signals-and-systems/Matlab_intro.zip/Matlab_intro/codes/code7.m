x = [1 2 3 4 ; 1 2 3 4];

y = [1 2 1 2 ; 1 2 1 2];

disp(x+y);

disp(x-y);

disp(x.*y);

disp(x./y);

disp(x.^y);

