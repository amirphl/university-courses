mychar = input('Enter a name: ', 's');
mynum = input('Enter a number: ');
disp(class(mynum));
