function [outputArg1] = test2(inputArg1)
%TEST2 Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = inputArg1+1;
end

