classdef student
    properties 
        name
        age
        ID
    end
    methods
        %constructor
        function obj = student(name, age, ID)
            obj.name = name;
            obj.age = age;
            obj.ID = ID;
        end
        %other methods
        function obj = setName(obj,name)
         obj.name = name;
        end
        function ID = getID(obj)
            ID = obj.ID;
        end
        function obj = ageUp(obj)
            obj.age = obj.age + 1;
        end
    end
end