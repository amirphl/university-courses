function [output] = f1(input0, input1)
%F1 Summary of this function goes here
%   Detailed explanation goes here
output = input0 .* (input0>input1);
end

