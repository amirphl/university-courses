for i = 1:10
    disp(cat(2,'iteration:', num2str(i)));
end

