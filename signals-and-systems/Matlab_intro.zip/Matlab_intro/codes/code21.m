t = 0:0.001:10;

function1 = @(x) cos(0.5*pi*x - 0.25*pi);
x = function1(t);

plot(t,x,'linewidth',2,'color',[1 0 0]);
axis([0 15 -1.5 1.5]);
legend('first function');
hold on;

function2 = @(x) sin(0.5*pi*x - 0.25*pi);
y = function2(t);

plot(t,y,'linewidth',2,'color',[0 0 1]);
axis([0 15 -1.5 1.5]);
legend('second function');
hold on;

function3 = @(f1,f2,x) f1(x) + f2(x);

z = function3(function1,function2,t);

plot(t,z,'linewidth',2,'color',[0 1 0]);
axis([0 15 -1.5 1.5]);
legend('third function');