x = 25;
disp(class(x));

x = uint32(x);
disp(class(x));
