tic
x = rand(10000,10000);
y = rand(10000,10000);
z = x.*y;
disp(toc);
