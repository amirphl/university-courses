x = [1 1 1 1 1 1 1 1 1 1 1 1 1];
X = dtft(x);
idtft(X);
