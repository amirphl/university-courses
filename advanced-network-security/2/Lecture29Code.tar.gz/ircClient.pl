#!/usr/bin/perl -w

##   ircClient.pl
##   Avi Kak (kak@purdue.edu)
##   revised April 22, 2015

##   This is a command-line IRC client.  I created this script by combining: (1) the
##   script ClientSocketInteractive.pl in Chapter 15 of my book "Scripting With
##   Objects"; (2) some portions from Paul Mutton's script "A Simple Perl IRC Client"
##   and user feedback scriplets that can be downloaded from
##   http://oreilly.com/pub/h/1964; and (3) some additional checks of my own for the
##   messages going from the client to the server.
##
##   To make a connection, your command line should look like
##
##      ircClient.pl  irc.freenode.net  6667  botrow  ##PurdueCompsec
##
##   where 'botrow' is your nick and '##PurdueCompsec' the name of the channel.
##   Obviously, 'irc.freenode.net' is the hostname of the server and 6667 the port
##   number.
##
##   After you are connected, to send a text string to the server, enter
##   
##      PRIVMSG  ##PurdueCompsec  :your actual text message goes here
##
##   where 'PRIVMSG' is the command name for sending a text message and
##   '##PurdueCompsec' the name of the channel.  What comes after the colon is the
##   text you want to send to to the channel.  Similarly, if you want to announce to
##   to the ##PurdueCompsec channel that you will be away for 10 minutes, you can
##   enter
##
##      AWAY ##PurdueCompsec :Back in 10 mins
##
##   If you want yourself to be unmarked as being away, all you need to enter is
##
##       AWAY
##
##   without any arguments to the command.  To quit a chat session, all you have to
##   say is
##
##       QUIT
##
##   It is normal for the server to return an ERROR message when you quit.
##
##   If you don't know where the command names PRIVMSG, AWAY, QUIT, etc., come from,
##   read the RFC1459 IRC standard.  That standard defines a total of 40 such
##   commands.
##
##   Also try PING, WHO, WHOIS, USERS, PART, QUIT, NAMES, LIST, VERSION,
##   STATS c, STATS l, STATS k, ADMIN, etc., with this command-line client.

use strict;

use IO::Socket;                                                                         #(A)

die "Usage:  Requires 4 arguments as in\n\n" .
    "        $0   host   port   nick   channel\n\n" .
    "Ex: ircClient.pl irc.freenode.net 6667 botrow \##PurdueCompsec\n"
    unless @ARGV == 4;                                                                  #(B)

my $server = shift;                                                                     #(C)
my $port = shift;                                                                       #(D)
my $nick = shift;                                                                       #(E)
my $login = $nick;                                                                      #(F)
my $channel = shift;                                                                    #(G)

my $sock = IO::Socket::INET->new(PeerAddr =>$server,                                    #(H)
                                 PeerPort =>$port,                                      #(I)
                                 Proto => 'tcp') or                                     #(J)
    die "Can't connect\n";                                                              #(K)

$SIG{INT} = sub { $sock->close; exit 0; };                                              #(L)

my @IRC_cmds = qw/ADMIN AWAY CONNECT ERROR INFO INVITE 
                  ISON JOIN KICK KILL LINKS LIST MODE 
                  NAMES NICK NOTICE OPER PART PASS PING 
                  PONG PRIVMSG QUIT REHASH RESTART SERVER 
                  SQUIT STATS SUMMON TIME TOPIC TRACE 
                  USER USERHOST USERS VERSION WALLOPS 
                  WHO WHOIS WHOWAS/;                                                    #(M)

print STDERR "[Connected to $server:$port]\n";                                          #(N)

# spawn a child process. The variable $pid is set to the PID of the child process in
# the main process.  However, in the child process, its value is set to 0.
my $pid =  fork();                                                                      #(O)
die "can't fork: $!" unless defined $pid;                                               #(P)

# Parent process: Use blocking read to receive messages incoming from the server and
# respond to those messages appropriately.  If there a need to send a message to the
# server, a message that is not a reply to something received from the server, the
# child process will take care of that.
if ($pid) {                                                                             #(Q)
    STDOUT->autoflush(1);                                                               #(R)
    # Log on to the server.  To log into a server that does not need a password, you
    # need to send the NICK and USER messages to the server as shown below. See
    # Section 3.1.3 of RFC 2812 for the syntax used for the USER message.
    print $sock "NICK $nick\r\n";                                                       #(S)
    print $sock "USER $login 0 * :A Handcrafted IRC Client\r\n";                        #(T)

    while (my $input = <$sock>) {                                                       #(U)
        # Check the numerical responses from the server.
        if ($input =~ /004/) {           # connection established                       #(V)
            # If connection established successfully, we terminate this `while' loop
            # and switch to the `while' loop in line (i) for downloading chat from
            # the server on a continuous basis:
            last;                                                                       #(W)
        } elsif($input =~ /PING/) {                                                     #(X)
            # Some servers require sending back PONG with the same characters as
            # received from the server:
            print "Found ping: $input";                                                 #(Y)
            if($input =~/:/) {                                                          #(Z)
                if(index($input, ":") != -1) {                                          #(a)
                    # Send PONG back with the received digits
                    my $digits = substr($input, index($input, ":") + 1, 
                            (length($input) - index($input, ":")));                     #(b)
                    print $sock "PONG $digits\r\n";                                     #(c)
                }
            }
        } elsif ($input =~ /433/) {                                                     #(d)
            die "Nickname is already in use.";                                          #(e)
        }
    }
    print "Joining the channel\n";                                                      #(f)
    print $sock "JOIN $channel\r\n";                                                    #(g)
    print "Waiting for a reply\n";                                                      #(g)
    while (my $input = <$sock>) {                                                       #(i)
        chomp $input;                                                                   #(j)
        if ($input =~ /^PING(.*)$/i) {                                                  #(k)
            # We must respond to PINGs to avoid being disconnected.
            print $sock "PONG $1\r\n";                                                  #(l)
        } else {                                                                        #(m)
            # Normally a user will be identified to you with a string like
            # 'nick!login_name@host'.  Abbreviate this to just the nick:
            $input =~ s/(^[^!]*)![^ ]*/$1/;                                             #(n)
            print "$input\n";                                                           #(o)
        }
    }
} else {                                                                                #(p)
    # Child process: send message to remote IRC server 
    my $msg;                                                                            #(q)
    while (defined( $msg = <STDIN> ) ) {                                                #(r)
        # Split the message into strings so that we can test the first string for a
        # valid IRC command:
        my @split_msg = grep $_, split /\s+/, $msg;                                     #(s)
        my @matches = grep /^$split_msg[0]$/, @IRC_cmds;                                #(t)
        @matches = grep {defined $_} @matches;                                          #(u)
        if (@matches) {                                                                 #(v)
            print $sock $msg;                                                           #(w)
            last if $matches[0] =~ /QUIT/;                                              #(x)
        } else {                                                                        #(y)
            print STDERR "Syntax error. Try again\n";                                   #(z)
        }
    }
}
