
// simple_ex.c:

void my_func(int a, int b, int c) {
    int x = 100;
}

void main() {
  my_func(1,2,3);
}
