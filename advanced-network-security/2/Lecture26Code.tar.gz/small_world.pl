#!/usr/bin/perl -w

# small_world.pl

# by Avi Kak  (kak@purdue.edu)

# updated October 23, 2008

# Generate a Watts-Strogatz small world network consisting
# of $N nodes.  Each node is directly connected to $K
# immediate neighbors that are located symmetrically in
# the ring lattice on two sides of the node.

# We will model the network as a hash.  The keys in the 
# hash are the node indices.  So if there are a total
# of N nodes in the network, the hash will consist of N
# <key,value> pairs. The value for each key is again a
# hash.  The keys for this inner hash at a given node in
# the network are the indices of the destination nodes at
# the outgoing arcs.  So if we focus on node $i in the network,
# and if 'base_graph' is the main hash representing the
# network, $base_graph{i} would stand for a hash consisting of
# the <key,value> pairs such that the keys are the destination
# nodes that the node $i is directly connected with and 
# values would be set to 1 for all such destintation nodes.
# For all other network nodes that are not the destination 
# nodes for the outgoing arcs emanating from $i, 
# $base_graph{i}{j} would be left undefined.  It is obviously 
# the case that if $base_graph{i}{j} is set to 1, then 
# $base_graph{j}{i} must also be set to 1.  And if we delete an 
# arc at node i by undefing $basic_graph{i}{j}, then that arc 
# is not completely deleted until we also undef $base_graph{j}{i}.  
# It is interesting to observe that each arc from node $i to 
# node $j gets a double representation, once in the hash 
# $base_graph{i} and then again in the hash $base_graph{j}.

# Of the various functions that are shown below, the functions
# make_base_graph() and rewire_base_graph() are based on the
# code in Mary Lynn Reed's article "Simulating Small-World
# Networks" that appeared in Dr. Dobb's Portal in April 2004.
# The functions shortest_paths() and display_shortest_distance()
# are based on the article "Empirical Study of Graph Properties
# with Particular Interest towards Random Graphs" by Lee Weinstein.


use strict;

my $out_dot_file = shift;

my $N = 20;                                                        #(A)
my $K = 4;                                                         #(B)

my $p = 0.08;                                                      #(C)

my $seed = time();                                                 #(D)
srand($seed);                                                      #(E)

my %base_graph = make_base_graph( $N, $K );                        #(F)

my %rewired_graph = rewire_base_graph( $p, %base_graph );          #(G)

display_graph_on_ring_lattice( %rewired_graph );                   #(H)

my %floyd_warshall_matrix = shortest_paths( %rewired_graph );      #(I)

display_shortest_distances( %floyd_warshall_matrix );              #(J)

my $dia = diameter( %floyd_warshall_matrix );                      #(K)

printf "Diameter of the graph is %.3f\n", $dia;                    #(L)

my $cluster_coeff = clustering_coefficient( %rewired_graph );      #(M)

printf "Average cluster coefficient is %.3f \n", $cluster_coeff;   #(N)

# The first arg below is the total number of nodes in the
# graph and the second arg the total number of neighbors.
# Choose an even number for the second arg so that the
# immediate neighbors of a node will be symmetrically placed
# on the two sides of the node.
my $plot_data = diameters_and_clustering_for_different_p(100, 4);  #(O)

plot_diameters_and_clustering_coefficients( $plot_data );          #(P)

#######################################################################
#                          Subroutines
#######################################################################

# This subroutine uses the GD::Graph package to construct 
# the plots shown in Figure 7.  The plot output is
# deposited in a file called 'SmallWorld.gif'.  The subroutine
# needs for its input a reference to an array that in turn
# contains references to the following three arrays: 1) an array
# of labels to use for the x-axis; 2) an array of the graph
# diameters for different values of probability; and 3) an
# array of clustering coefficients for different value of 
# probability.
sub plot_diameters_and_clustering_coefficients {                   #(Q)
    my $plot_data = shift;

    use GD::Graph::lines;                                          
    use GD::Graph::Data;                                           
    
    my $sw_graph = new GD::Graph::lines();                         
    $sw_graph->set(                                                
    	x_label => 'probability p',
    	y_label => 'L(p)/L(0) and C(p)/C(0)',
    	title => 'Small World Simulation',
    	y_max_value => 1.0,
    	y_min_value => 0,
    	y_tick_number => 5,
    	y_label_skip => 1,
        x_labels_vertical => 1,
        x_label_skip => 4,
        x_label_position => 1/2,
    	line_types => [ 1, 2 ],
    	line_type_scale => 8,
    	line_width => 3,
    ) or warn $sw_graph->error;
    
    $sw_graph->set_legend( 'L(p)/L(0)', 'C(p)/C(0)' );             
    $sw_graph->plot($plot_data) or die $sw_graph->error;           
    my $ext = $sw_graph->export_format;                            
    open( OUTPLOT , ">SmallWorld.$ext") or                         
    	die "Cannot open SmallWorld.$ext for write: $!";
    binmode OUTPLOT;                                               
    print OUTPLOT $sw_graph->gd->$ext();                           
    close OUTPLOT;                                                 
}


# This subroutine calcuates the diameter of a graph of nodes
# and its clustering coefficient for different values of
# the probability p: 
sub diameters_and_clustering_for_different_p {                     #(R)
    my $N = shift;        # The total number of nodes in graph
    my $K = shift;        # The immediate neighbors of each node
    my %base_graph = make_base_graph( $N, $K );
    
    # Figure out the values of the probability $p for which
    # you want to compute the diameter and the clustering
    # coefficient.  To demonstrate the small-world phenomenon,
    # you need a logarithmic scale for p.  We will choose 
    # values for p that span the range 0.0001 and 1.0 in such
    # a way that the tick marks on the horizontal axis are
    # equispaced.  Note that on a logarithmic scale, the middle
    # point between two given points is the geometric mean of
    # the two.
    my $x = 1.0 / sqrt(10);
    my $y = $x * sqrt( $x );
    my $z = sqrt( $x );
    my @p_array = (0.0001, $y * 0.001, $x * 0.001, $z * 0.001, 0.001, 
                           $y * 0.01,  $x * 0.01,  $z * 0.01,  0.01, 
                           $y * 0.1,   $x * 0.1,   $z * 0.1,   0.1, 
                           $y * 1.0,   $x * 1.0,   $z * 1.0,   1.0);
    my $dia_no_rewire;
    my $clustering_no_rewire;
    my @dia_array;
    my @clustering_coeffs;
    my @x_axis_tick_labels;
    foreach my $p (@p_array) {
        my %rewired_graph = rewire_base_graph( $p, %base_graph );    
        my %floyd_warshall_matrix = shortest_paths( %rewired_graph );
        my $dia = diameter( %floyd_warshall_matrix );    
        $dia_no_rewire = $dia if $p == $p_array[0];
        my $dia_ratio = $dia / $dia_no_rewire;
        my $cluster_coeff = clustering_coefficient( %rewired_graph );
        $clustering_no_rewire = $cluster_coeff if $p == $p_array[0];
        my $clustering_ratio = $cluster_coeff / $clustering_no_rewire;
        printf "For p=%.5f,  L(p)/L(0) = %.2f  C(p)/C(0) = %.2f \n", 
                          $p, $dia_ratio, $clustering_ratio;
        push @dia_array, $dia_ratio;
        push @clustering_coeffs, $clustering_ratio;
        if ( ($p == 0.0001) || ($p == 0.001) || ($p == 0.01) 
             || ($p == 0.1)  || ($p == 1.0) ) {
            push @x_axis_tick_labels, $p;
        } else {
            push @x_axis_tick_labels, undef;
        }
    }                                
    return [ \@x_axis_tick_labels, \@dia_array, \@clustering_coeffs ];
}

# Create the base graph consisting of nodes and arcs.  As explained in
# the top-level comments, a graph is represented by hash of a hash.
# The keys in the outer hash are the node indices, and the values
# anonymous hashes whose keys are destination nodes connected to a
# given node in the graph and whose values are 1 for those destination
# nodes:
sub make_base_graph {                                              #(S)
    my $N = shift;     # total number of nodes in the graph
    my $k = shift;     # neighbors directly connected on lattice
    my %graph;
    foreach my $i (0..$N-1) {
        my $left = int($K / 2);     # Number of nodes to connect to the left
        my $right = $K - $left;     # Number of nodes to connect to the right
        foreach my $j (1..$left) {
            my $ln = ($i - $j) % $N;
            $graph{$i}{$ln} = 1;
            $graph{$ln}{$i} = 1;
        }
        foreach my $j (1..$right) {
            my $rn = ($i + $j) % $N;
            $graph{$i}{$rn} = 1;
            $graph{$rn}{$i} = 1;
        }
    }
    return %graph;
}

# Rewire each edge with probability $p
sub rewire_base_graph {                                            #(T)
    my $p = shift;         # probability for rewiring a link    
    my %graph = @_;
    my $N = keys %graph;   # total number of nodes in the graph

    foreach my $i (keys %graph) {
        foreach my $j (keys %{$graph{$i}}) {
            my $r = rand();
            if ($r < $p) {
                # randomly select a new node $jnew to connect to $i
                my $done = 0;
                my $jnew;
                while (!$done) {
                    $jnew = int($N * rand());
                    if ( ($jnew != $i)  && ($jnew != $j) ) {
                        $done = 1;
                    }
                }
                # remove edge $i  <--> $j
                undef $graph{$i}{$j};
                undef $graph{$j}{$i};
                # add edge $i <-->  $jnew
                $graph{$i}{$jnew}++;
                $graph{$jnew}{$i}++;
            }
        }
    }
    return %graph;
}               

# This is the function that is called to display a ring lattice.
# It dumps its output into a DOT file that can then be visually
# displayed as a ring lattice of nodes by the neato program.
sub display_graph_on_ring_lattice {                                #(U)
    die "No output DOT file specified" if !defined( $out_dot_file );
    my %argGraph = @_;
    my $NumNodes = keys %argGraph;    # number of nodes in the graph
    my %graph;
    foreach my $i (0..$NumNodes-1) {
        foreach my $j (0..$NumNodes-1) {
            $graph{$i}{$j} = $argGraph{$i}{$j};
        }
    }

    use constant PI => 3.14159;

    open OUT, "> $out_dot_file";
    print OUT "graph WS { \n";
    print OUT "node [shape=point,color=blue,width=.1,height=.1];\n";

    foreach my $i (keys %graph) {
        my $delta_theta = 2 * PI / $NumNodes;
        my $posx = sin( $i * $delta_theta );
        my $posy = cos( $i * $delta_theta );   
        print OUT "$i [pos = \"$posx,$posy!\" ];";
    }
    print OUT "\n";

    # This is my attempt to decrease the "strength"
    # associated with each edge in order to make it
    # more pliable for curving by the spline option
    # set in the command line:
    print OUT "edge [weight=0.001];\n"; 

    foreach my $i (keys %graph) {
        foreach my $j (keys %{$graph{$i}}) {
            print OUT "$i -- $j;\n" if $graph{$i}{$j};
            undef $graph{$j}{$i};
        #        print OUT "$i -- $j\n";
        }
    }
    print OUT "}\n";
    close OUT;
}


# This is an implementation of the Floyd-Warshall All Pairs Shortest
# Path algorithm.  Note that this is not the most efficient way to
# compute pairwise shortest distances in a graph; however, it is easy to
# program.  The time complexity of this algorithm is O(N^3) where N is
# the number of nodes in the graph.  A faster version of this 
# algorithm is Seidel's All Pairs Shortest Distance Algorithm.
sub shortest_paths {                                               #(V)
    my %argGraph = @_;                # Copy argument graph into %g:
    my $N = keys %argGraph;           # Number of nodes in graph
    my %g;
    foreach my $i (0..$N-1) {
        foreach my $j (0..$N-1) {
            $g{$i}{$j} = $argGraph{$i}{$j};
        }
    }
    my %tempg;
    foreach my $p (0..$N-1) {    
        foreach my $q (0..$N-1) {
            $g{$p}{$q} = 0 if $p == $q;
            $g{$p}{$q} = 1000000 if !defined( $g{$p}{$q} );
        }
    }
    foreach my $t (0..$N-1) {
        foreach my $i (0..$N-1) {        
            foreach my $j (0..$N-1) {        
                $tempg{$i}{$j} = $g{$i}{$j} < $g{$i}{$t} + $g{$t}{$j} ?
                                     $g{$i}{$j} : $g{$i}{$t} + $g{$t}{$j};
            }
        }
        %g = %tempg;
    }
    # Undefine the edges that were not there to begin with:
    foreach my $i (0..$N-1) {
        foreach my $j (0..$N-1) {
            undef $g{$i}{$j} if $g{$i}{$j} >= 1000000;
        }
    }
    return %g;
}

# Compute the diameter as the average of all pairwise shortest
# path-lengths in the graph:
sub diameter {                                                     #(W)
    my %graph = @_;
    my $N = keys %graph;           # Number of nodes in graph
    my $diameter = 0;
    foreach my $p (0..$N-1) {
        foreach my $q ($p..$N-1) {
            $diameter += $graph{$p}{$q} if defined $graph{$p}{$q};
        }
    }
    return $diameter / ($N * ($N - 1) / 2.0 );
}

# Utility routine good for troubleshooting:
sub display_shortest_distances {                                   #(X)
    my %g = @_;               # Copy argument graph into %g:
    my $N = keys %g;          # Number of nodes in graph  
    foreach my $p (0..$N-1) {
        foreach my $q (0..$N-1) {
            if ( defined($g{$p}{$q}) ) {
                print "$g{$p}{$q} ";
            }
            else {
                print "  ";
            }
        }
        print "\n";
    }
}

# Calculates the clustering coefficient of a graph.  See
# the text for what is meant by this coefficient.
sub clustering_coefficient {                                       #(Y)
    my %g = @_;
    my $N = keys %g;
    my @cluster_coeff_arr;
    my %neighborhood;
    # Initialize the neighborhood for each node. Obviously,
    # each node belongs to its own neigborbood:
    foreach my $i (0..$N-1) {
        $neighborhood{$i} = [$i];
    }
    foreach my $i (0..$N-1) {
        foreach my $j (0..$N-1) {        
            if (defined($g{$i}{$j}) && ($g{$i}{$j} == 1)) {
                push @{$neighborhood{$i}}, $j;
            }
        }
    }
    # For troubleshooting:
    # foreach my $i (0..$N-1) {
    #     print "@{$neighborhood{$i}}\n";
    # }
    foreach my $i (0..$N-1) {
        my $n = @{$neighborhood{$i}};        # size of neighborhood
        foreach my $j (@{$neighborhood{$i}}) {
            foreach my $k (@{$neighborhood{$i}}) {
                if (defined($g{$j}{$k})) {
                    $cluster_coeff_arr[$i]++ if $g{$j}{$k} == 1;
                }
            }
        }
        # Divide by n(n-1) because every edge in the neighborhood will be
        # counted twice.  Ordinarily, you would divide by n(n-1)/2.
        $cluster_coeff_arr[$i] /= $n * ($n - 1) unless $n == 1;

        # For troubleshooting:
        # print "for $i, the cluster coefficient is $cluster_coeff_arr[$i]\n";
    }
    my $total = 0.0;
    foreach my $i (0..$N-1) {
        $total += $cluster_coeff_arr[$i] if defined $cluster_coeff_arr[$i];
    }
    my $average_cluster_coeff = $total / $N;
    # For troubleshooting:
    # print "the average cluster coefficient is $average_cluster_coeff\n";
    return $average_cluster_coeff;
}
