#!/usr/bin/perl -w

# Metropolis_Hastings.pl

# by Avi Kak  (kak@purdue.edu)

# The Metropolis-Hastings sampling algorithm is used to generate a
# sequence of samples from a given probability density function.
# Such a sequence of samples can be used in MCMC (Markov-Chain 
# Monte-Carlo) simulations.

# The workhorse of the code here is the metropolis_hastings()
# function that takes one argument --- the number of samples
# you want the function to return.  The implementation is based
# on the logic shown in Figure 5 of "An Introduction to MCMC for
# Machine Learning" by Andrieu, De Freitas, Doucet, and Jordan
# that appeared in the journal Machine Learning in 2003.  The
# desired density function used is that same as in their Figure 6.

# The code shown here deposits its histogram in a gif file
# called histogram.gif.  The visual display in the gif file
# shows both the histogram for the samples and the true
# desired density function for the samples.

use strict;
use Math::Random;           # for normal and uniform densities
use constant PI => 4 * atan2( 1, 1 );
use Math::Big qw/euler/;    # euler(x) returns e**x
use Algorithm::MinMax;      # efficiently calculates min and max in an array
use GD::Graph::mixed;       # for bar graphs and line plots

# Useful for creating reproducible results:
random_seed_from_phrase( 'hellojello' );

my @samples = metropolis_hastings(500);
#my @samples = metropolis_hastings(100);

# The following call returns a reference to an array whose
# first element is an anonymous array consisting of the 
# horizontal labels for the histogram, whose second element
# an anonymous array consisting of the bin counts, and third
# element an anonymous array consisting of the samples of
# the desired density function:
my $histogram = make_histogram( @samples );

plot_histogram( $histogram );

#######################################################################
#                          Subroutines
#######################################################################

# This subroutine uses the GDGraph Perl module to create a visual
# display that shows both the bar graph for the histogram
# of the MCMC samples created by the metropolis_hastings() function
# and a line plot of the desired density function for such 
# samples.  The data fed to this subroutine is output by the
# make_histogram() subroutine.
sub plot_histogram {                                             
    my $plot_data = shift;                                       
    my $histogram_bars = new GD::Graph::mixed();                         
    $histogram_bars->set( 
        types => [ qw( bars lines ) ]
    );
    $histogram_bars->set(                                                
    	x_label => 'sample values',
    	y_label => 'estimated density',
    	title => 'Histogram of Metropolis-Hastings Samples',
    	y_tick_number => 5,
    	y_label_skip => 1,
        y_max_value => 0.15,
        y_min_value => 0.0,
        x_labels_vertical => 1,
        x_label_skip => 4,
        x_label_position => 1/2,
    	line_type_scale => 8,
    	line_width => 3,
    ) or warn $histogram_bars->error;
    
    $histogram_bars->set_legend( 'histogram of sample values' );             
    $histogram_bars->plot($plot_data) or die $histogram_bars->error;           
    my $ext = $histogram_bars->export_format;                            
    open( OUTPLOT , ">histogram.$ext") or                         
    	die "Cannot open histogram.$ext for write: $!";
    binmode OUTPLOT;                                               
    print OUTPLOT $histogram_bars->gd->$ext();                           
    close OUTPLOT;                                                 
}


# This subroutine constructs a histogram from the MCMC samples
# constructed by the metropolis_hastings() subroutine. 
# This subroutine also constructs an array from the desired
# density function whose calculation is encapsulated in the
# desired_density.pl subroutine.  Yet another array synthesized
# in this subroutine consists of the labels to use for the
# visual display constructed by the plot_histogram() subroutine.
sub make_histogram {
    my @data = @_;
    my $N = @data;
    my ($min, $max) = Algorithm::MinMax->minmax( \@data );
    my $num_bins = 30;
    my @hist = (0.0) x $num_bins;
    my @desired_density;
    my $bin_width = ($max - $min) / $num_bins;
    my @x_axis_labels;
    foreach my $x (@data) {
        my $bin_index = int( ($x - $min) / $bin_width );
        $hist[ $bin_index ]++;    
    }
    foreach my $i (0..$num_bins) {
        my $xval_at_bin_edge = $min + $i * $bin_width;
        push @x_axis_labels, sprintf( "%.2f", $xval_at_bin_edge );
        push @desired_density, desired_density($xval_at_bin_edge);
    }
    @hist = map { $_ / $N } @hist;
    my ($hmin, $hmax) = Algorithm::MinMax->minmax( \@hist );
    my ($dmin, $dmax) = Algorithm::MinMax->minmax( \@desired_density );
    @desired_density = map { $_ * ($hmax / $dmax) } @desired_density;
    return [ \@x_axis_labels, \@hist, \@desired_density ];
}
    

# This subroutine constructs a Markov chain according to the
# Metropolis-Hastings algorithm.  This algorithm needs a 
# proposal density, whose primary role is to help select
# the next sample given the current sample, and the desired
# density for the samples.  The number of samples constructed
# is determined by the sole argument to the subroutine.  Note
# that ideally you are supposed to discard many initial
# samples since it can take a certain number of iterations
# for the actual density of the samples to approach the
# desired density.
sub metropolis_hastings {    
    my $N = shift;                # Number of samples
    my @arr;
    my $sample = 0;
    foreach my $i (0..$N-1) {
        print "Iteration number: $i\n" if $i % ($N / 10) == 0;

        # Get proposal probability q( $y | $x ).
        my ($newsample, $prob) = get_sample_using_proposal( $sample ); 
        my $a1 = desired_density( $newsample ) / desired_density( $sample );

        # IMPORTANT: In our case, $a2 shown below will always be 1.0
        # because the proposal density norm($x | $y) is symmetric with
        # respect to $x and $y:
        my $a2 = proposal_density( $sample, $newsample ) / $prob;
        my $a = $a1 * $a2;
        my $u = random_uniform();
        if ( $a >= 1 ) {
            $sample = $newsample;
        } else {
            $sample = $newsample if $u < $a;
        }
        $arr[$i] = $sample;
    }
    return @arr;
}

# This subroutine along with the subroutine proposal_density() do
# basically the same thing --- implement the normal density as the
# proposal density.  It is called proposal density because it is
# used to propose the next sample in the Markov chain.  The
# subroutine shown below returns both the proposed sample for
# the next time step and its probability according to 
# the normal distribution norm($x, $sigma ** 2).   The next 
# subroutine, proposal_density(), only evaluates the density 
# for a given sample value.
sub get_sample_using_proposal {
    my $x = shift;
    my $mean = $x;      # for proposal_prob($y|$x)  =  norm($x, $sigma ** 2) 
    my $sigma = 10;
    my $sample = random_normal( 1, $mean, $sigma );
    my $gaussian_exponent = - (($sample - $mean)**2) / (2 * $sigma * $sigma);
    my $prob = ( 1.0 / ($sigma * sqrt( 2 * PI ) ) ) * euler( $gaussian_exponent );
    return ($sample, $prob);
}            

# As mentioned above, this subroutine returns the value of the 
# norm($x, $sigma) at a given sample value where $x is the mean
# of the density.  The sample value where the density is to be
# known is supplied to the subroutine as its first argument.
sub proposal_density {
    my $sample = shift;
    my $mean = shift;
    my $sigma = 10;          # for  norm($mean, $sigma ** 2)
    my $gaussian_exponent = - (($sample - $mean)**2) / (2 * $sigma * $sigma);
    my $prob = ( 1.0 / ($sigma * sqrt( 2 * PI ) ) ) * euler( $gaussian_exponent );
    return $prob;
}

# This implements the desired density for an MCMC experiment.  That is,
# we want the first-order distribution of the Markov chain samples to
# possess the density as described by the function shown here:
sub desired_density {
    my $x = shift;
    return 0 if ($x < -10.0) or ($x > 20.0);
    my $prob = 0.3 * euler(-0.2*($x**2)) +  0.7 * euler(-0.2*(($x - 10.0)**2));
    return $prob;
}
