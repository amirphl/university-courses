#!/bin/sh

mainpid=`ps ax | grep -e RepeatedAttack | grep -v grep | awk '{print $1}'`
kill -9 $mainpid
while true
do 
    mypid=`ps ax | grep -e TestHTTPServer | grep -v grep | awk '{print $1}'`
    if [ "$mypid" ] ;then
        echo "TestHTTPServer process found: " $mypid
        kill -9 $mypid
    else
        exit 0  
    fi
done
 
