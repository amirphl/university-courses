#!/bin/sh

##  RepeatedAttack.sh

count=1
while true
do 
    job="TestHTTPServerWithNoCRLF.py  10.0.0.8  /"
    eval ${job} &
    count=`expr $count + 1`
    echo "starting a new process at iteration: " $count
    sleep 15
done
