#!/usr/bin/env python

##  TestHTTPServerWithNoCRLF.py
##  Avi Kak 
##  April 16, 2016

import sys
import socket
import time

if len(sys.argv) < 3:                                                        #(A)
    sys.exit( """\nNeed at least two command line arguments"""
              """\nthe first naming the host and the second"""
              """\nnaming the document at the host""" )
getdoc = run_only_once = None                                                #(B)
EOL = "\r\n"                                                                 #(C)
BLANK = EOL * 2                                                              #(D)
host = sys.argv[1]                                                           #(E)
getdoc = sys.argv[2]                                                         #(F)
if len(sys.argv) == 4:                                                       #(G)
    run_only_once = sys.argv[3]                                              #(H)
while True:                                                                  #(I)
    try:                                                                     #(J)
        sock = socket.socket( socket.AF_INET, socket.SOCK_STREAM )           #(K)
        sock.connect( (host, 80) )                                           #(L)
    except socket.error, (value, message):                                   #(M)
        if sock:                                                             #(N)
            sock.close()                                                     #(O)
        print "Could not establish a client socket: " + message              #(P)
        sys.exit(1)                                                          #(Q)
    sock.send( str( "GET %s HTTP/1.1 %s Host: %s%s" ) % (getdoc, EOL, host, EOL) )   
                                                                             #(R)
    print "sent another incomplete request to HTTP server"                   #(S)
    time.sleep(10)                                                           #(T)
    if run_only_once:                                                        #(U)
        time.sleep(200)                                                      #(V)
        sys.exit("exiting after only one attempt")                           #(W)
