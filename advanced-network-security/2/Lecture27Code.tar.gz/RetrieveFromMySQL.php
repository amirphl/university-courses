<?php
    // by Avi Kak (kak@purdue.edu)
    // for a simple example of SQL Injection Attack

    $username = $_GET["user"];                                                 //(A)
    $userpassword = $_GET["password"];                                         //(B)

    try {                                                                      //(C)
        $db = new PDO('mysql:host=localhost; dbname=Manager_db; 
                  charset=utf8mb4', "$username", "$userpassword");             //(D)
        $result = $db->query("SELECT * FROM Operator_view");                   //(E)
        echo "Successful connection with the MySQL database";                  //(F)
    } catch (PDOException $e) {                                                //(G)
        echo "Connection with MySQL failed: " . $e->getMessage();              //(H)
    }

    echo "<table border='1'>                                                
         <tr>                                     
         <th>Operator Name</th>                   
         <th>Equipment</th>                       
         <th>Deadline</th>                        
         </tr>";                                                               //(I)

    while( $row = $result->fetch(PDO::FETCH_ASSOC) ) {                         //(J)
        echo "<tr>";                                                           //(K)
        echo "<td>" . $row['operator_name'] . "</td>";                         //(L)
        echo "<td>" . $row['equipment'] . "</td>";                             //(M)
        echo "<td>" . $row['deadline'] . "</td>";                              //(N)
        echo "</tr>";                                                          //(O)
    }
    echo "</table>";                                                           //(P)
?>
