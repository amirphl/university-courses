#include <avr/io.h>

#define F_CPU	4000000UL
#include <util/delay.h>

int flag = 0;

ISR(INT0_vect){
	flag = 1;
}

ISR(INT1_vect){
	flag = 0;
}

int main(void)
{
	
	char indexes[5];
	indexes[0] = 0b11001111;
	indexes[1] = 0b10100100;
	indexes[2] = 0b10110000;
	indexes[3] = 0b10011001;
	indexes[4] = 0b10010010;
	DDRA = 0xFF;	// Configure port B as output
	GICR = 1<<INT0 | 1<<INT1;
	
	
	MCUCSR = 1<<ISC01 | 1<<ISC00;
	MCUCSR = 1<<ISC11 | 1<<ISC10;
	sei();
	int i = 0;
	PORTA = indexes[i]
	while(1) {
		if(flag == 0) {
			continue;
		} else {
			_delay_ms(500);
			i = (i + 1) % 5;
		}
	}
	
	return 0;
}