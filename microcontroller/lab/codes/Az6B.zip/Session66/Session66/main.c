

 #include <avr\io.h>
 #include <avr\interrupt.h>
 #include <avr\wdt.h>
#include <util\delay.h>


int counter1 = 0;
int counter2 = 0;

ISR(INT0_vect){
	if (counter1%2 == 0) {
		PORTC = 0b00000000;
		} else {
		PORTC = 0b00000010;
	}
	counter1++;
}

ISR(INT1_vect){
	PORTC = 0b00000010;
	_delay_ms(2000);
	PORTC = 0b00000000;
}

 int main(void)
 {
	 DDRD = 0b11110011;
	 DDRC = 0b00000010;
	 PORTD = 0b00001100;
	 PORTC = 0b00000000;
	 GICR = 1<<INT0 | 1<<INT1;
	 
	 
	 MCUCSR = 1<<ISC01 | 1<<ISC00;
	 MCUCSR = 1<<ISC11 | 1<<ISC10;
	 sei();
	 while(1)
	 {
	 }
	 
	 return 0;
 }

