

#include <avr\io.h>
#include <avr\interrupt.h>
#include <avr\wdt.h>
#include <util\delay.h>


int counter1 = 0;
int counter2 = 0;

ISR(INT0_vect){
	sei();
		char last_value = PINC;
	PORTC = 0b00000010;
	_delay_ms(50);
	PORTC = last_value;
}

ISR(INT1_vect){
	sei();
		char last_value = PINC;
	PORTC = 0b00000010;
	_delay_ms(20);
	PORTC = last_value;
}

int main(void)
{
	DDRD = 0b11110011;
	DDRC = 0b00000010;
	DDRA = 0b00000010;
	PORTD = 0b00001100;
	PORTC = 0b00000000;
	GICR = 0b11000000;
	MCUCSR = 0b00001111;

	sei();
	while(1)
	{
	}
	
	return 0;
}

