from django.apps import AppConfig


class LoginBruteConfig(AppConfig):
    name = 'login_brute'
