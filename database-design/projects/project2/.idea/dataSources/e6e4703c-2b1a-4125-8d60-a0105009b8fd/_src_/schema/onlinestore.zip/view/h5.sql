CREATE VIEW h5 AS
  (SELECT
     `m4`.`shopId`    AS `shopId`,
     `m4`.`productId` AS `productId`,
     `m4`.`total`     AS `total`
   FROM `onlinestore`.`m4`
   WHERE (`m4`.`total` >= (SELECT `u`.`total`
                           FROM `onlinestore`.`m4` `u`
                           WHERE (`m4`.`shopId` = `u`.`shopId`))));
