CREATE TRIGGER before_accept_customer_order
BEFORE INSERT ON customerorders
FOR EACH ROW
  BEGIN
    SELECT T.id
    INTO @transmitter
    FROM transmitters AS T
    WHERE T.status = 'free' AND T.shopId = NEW.shopId
    LIMIT 1;

    IF (@transmitter IS NULL)
    THEN
      SET NEW.status = 'rejected';
    ELSE
      UPDATE transmitters AS T
      SET status = 'sending'
      WHERE T.id = @transmitter;

      SET NEW.status = 'sending';

      INSERT INTO shipment (transmitterId, orderId) VALUES (@transmitter, NEW.id);
    END IF;
  END;
