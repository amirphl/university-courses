CREATE VIEW transmitteraverageall AS
  (SELECT
     `r`.`id`      AS `id`,
     avg(`r`.`pr`) AS `average`
   FROM (SELECT
           `s`.`transmitterId`         AS `id`,
           (`c`.`value` * `p`.`price`) AS `pr`
         FROM ((`onlinestore`.`temporaryshipment` `s`
           JOIN `onlinestore`.`temporarycustomerorders` `c` ON ((`s`.`orderId` = `c`.`id`))) JOIN
           `onlinestore`.`product` `p` ON ((`c`.`productId` = `p`.`id`)))
         UNION ALL SELECT
                     `s`.`transmitterId`         AS `id`,
                     (`c`.`value` * `p`.`price`) AS `pr`
                   FROM ((`onlinestore`.`temporaryshipment` `s`
                     JOIN `onlinestore`.`temporarycustomerorders` `c` ON ((`s`.`orderId` = `c`.`id`))) JOIN
                     `onlinestore`.`product` `p` ON ((`c`.`productId` = `p`.`id`)))) `r`
   GROUP BY `r`.`id`);
