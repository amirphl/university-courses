CREATE VIEW h2 AS
  (SELECT
     `m1`.`shopId`    AS `shopId`,
     `m1`.`productId` AS `productId`,
     `m1`.`total`     AS `total`
   FROM `onlinestore`.`m1`
   WHERE (`m1`.`total` >= (SELECT `u`.`total`
                           FROM `onlinestore`.`m1` `u`
                           WHERE (`m1`.`shopId` = `u`.`shopId`))));
