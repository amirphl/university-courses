CREATE VIEW h1 AS
  (SELECT
     `m0`.`shopId`    AS `shopId`,
     `m0`.`productId` AS `productId`,
     `m0`.`total`     AS `total`
   FROM `onlinestore`.`m0`
   WHERE (`m0`.`total` >= (SELECT `u`.`total`
                           FROM `onlinestore`.`m0` `u`
                           WHERE (`m0`.`shopId` = `u`.`shopId`))));
