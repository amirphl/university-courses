CREATE PROCEDURE add_customer(IN us VARCHAR(100), IN pa VARCHAR(30), IN em VARCHAR(150), IN fi VARCHAR(100),
                              IN la VARCHAR(100), IN po CHAR(10), IN ge ENUM ('man', 'woman'), IN cr INT(10) UNSIGNED)
  BEGIN
    INSERT INTO customers (username, password, email, first_name, last_name, postal_code, gender, credit)
    VALUES (us, sha2(pa, 256), em, fi, la, po, ge, cr);
  END;
