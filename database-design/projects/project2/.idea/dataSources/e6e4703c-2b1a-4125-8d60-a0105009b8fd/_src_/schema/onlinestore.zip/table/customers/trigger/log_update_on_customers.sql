CREATE TRIGGER log_update_on_customers
AFTER UPDATE ON customers
FOR EACH ROW
  BEGIN
    INSERT INTO updatecustomerlog (username, dat) VALUES (NEW.username, current_timestamp);
  END;
