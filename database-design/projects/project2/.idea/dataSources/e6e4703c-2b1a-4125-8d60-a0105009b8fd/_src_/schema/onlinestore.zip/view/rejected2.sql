CREATE VIEW rejected2 AS
  (SELECT
     `c`.`customerEmail` AS `customerEmail`,
     `t`.`phone_number`  AS `phone_number`
   FROM (`onlinestore`.`temporarycustomerorders` `c`
     JOIN `onlinestore`.`temporarycustomers` `t` ON ((`c`.`customerEmail` = `t`.`email`)))
   WHERE (`c`.`status` = 'rejected'));
