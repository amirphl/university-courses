CREATE VIEW rejected1 AS
  (SELECT
     `c`.`customerUsername` AS `customerUsername`,
     `c`.`phone_number`     AS `phone_number`
   FROM `onlinestore`.`customerorders` `c`
   WHERE (`c`.`status` = 'rejected'));
