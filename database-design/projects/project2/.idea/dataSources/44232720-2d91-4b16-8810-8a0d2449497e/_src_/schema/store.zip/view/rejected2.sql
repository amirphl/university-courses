CREATE VIEW store.rejected2 AS
  (SELECT
     `c`.`customerEmail` AS `customerEmail`,
     `t`.`phone_number`  AS `phone_number`
   FROM (`store`.`temporarycustomerorders` `c`
     JOIN `store`.`temporarycustomers` `t` ON ((`c`.`customerEmail` = `t`.`email`)))
   WHERE (`c`.`status` = 'rejected'));
