CREATE TRIGGER store.log_update_on_customers
AFTER UPDATE ON store.customers
FOR EACH ROW
  BEGIN
    INSERT INTO updatecustomerlog (username, pre_email, new_email, pre_password, new_password, pre_credit, new_credit)
    VALUES (NEW.username, OLD.email, NEW.email, OLD.password, NEW.password, OLD.credit, NEW.credit);
  END;
