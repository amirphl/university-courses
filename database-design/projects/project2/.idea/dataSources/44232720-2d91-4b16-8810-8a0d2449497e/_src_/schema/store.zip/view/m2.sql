CREATE VIEW store.m2 AS
  (SELECT
     `m1`.`shopId`    AS `shopId`,
     `m1`.`productId` AS `productId`,
     `m1`.`total`     AS `total`
   FROM `store`.`m1`
   WHERE (NOT ((`m1`.`shopId`, `m1`.`productId`, `m1`.`total`) IN (SELECT
                                                                     `h2`.`shopId`,
                                                                     `h2`.`productId`,
                                                                     `h2`.`total`
                                                                   FROM `store`.`h2`))));
