CREATE VIEW store.s AS
  (SELECT
     `c`.`shopId`     AS `shopId`,
     `c`.`productId`  AS `productId`,
     sum(`c`.`value`) AS `total`
   FROM `store`.`customerorders` `c`
   GROUP BY `c`.`shopId`, `c`.`productId`)
  UNION ALL (SELECT
               `t`.`shopId`     AS `shopId`,
               `t`.`productId`  AS `productId`,
               sum(`t`.`value`) AS `sum(T.value)`
             FROM `store`.`temporarycustomerorders` `t`
             GROUP BY `t`.`shopId`, `t`.`productId`);
