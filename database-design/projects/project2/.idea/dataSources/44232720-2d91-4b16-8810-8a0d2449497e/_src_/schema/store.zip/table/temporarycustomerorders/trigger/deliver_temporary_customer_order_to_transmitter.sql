CREATE TRIGGER store.deliver_temporary_customer_order_to_transmitter
AFTER INSERT ON store.temporarycustomerorders
FOR EACH ROW
  BEGIN

    DECLARE transmitter INT UNSIGNED;

    IF NEW.status != 'rejected'
    THEN

      SELECT T.id
      INTO transmitter
      FROM transmitters AS T
      WHERE T.status = 'free' AND T.shopId = NEW.shopId
      LIMIT 1;

      IF transmitter
      THEN
        UPDATE transmitters AS T
        SET status = 'sending'
        WHERE T.id = transmitter;
        INSERT INTO temporaryshipment (transmitterId, purchase_time, customerEmail, shopId, productId)
        VALUES (transmitter, NEW.purchase_time, NEW.customerEmail, NEW.shopId, NEW.productId);

      END IF;
    END IF;
  END;
