CREATE TRIGGER store.hash_password
BEFORE UPDATE ON store.customers
FOR EACH ROW
  BEGIN
    SET NEW.password = sha1(NEW.password);
  END;
