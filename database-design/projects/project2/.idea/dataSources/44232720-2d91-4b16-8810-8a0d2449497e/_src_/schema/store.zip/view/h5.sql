CREATE VIEW store.h5 AS
  (SELECT
     `m4`.`shopId`    AS `shopId`,
     `m4`.`productId` AS `productId`,
     `m4`.`total`     AS `total`
   FROM `store`.`m4`
   WHERE `m4`.`total` >= ALL (SELECT `u`.`total`
                              FROM `store`.`m4` `u`
                              WHERE (`m4`.`shopId` = `u`.`shopId`)));
