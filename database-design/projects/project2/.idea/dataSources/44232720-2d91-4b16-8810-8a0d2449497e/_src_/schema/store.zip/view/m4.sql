CREATE VIEW store.m4 AS
  (SELECT
     `m3`.`shopId`    AS `shopId`,
     `m3`.`productId` AS `productId`,
     `m3`.`total`     AS `total`
   FROM `store`.`m3`
   WHERE (NOT ((`m3`.`shopId`, `m3`.`productId`, `m3`.`total`) IN (SELECT
                                                                     `h4`.`shopId`,
                                                                     `h4`.`productId`,
                                                                     `h4`.`total`
                                                                   FROM `store`.`h4`))));
