CREATE TRIGGER store.log_update_on_transmitters
AFTER UPDATE ON store.transmitters
FOR EACH ROW
  BEGIN
    INSERT INTO updatetransmitterlog (transmitterId, pre_status, new_status)
    VALUES (NEW.id, OLD.status, NEW.status);
  END;
