CREATE PROCEDURE store.charge_account(IN us VARCHAR(100), IN cr INT(10) UNSIGNED)
  BEGIN
    IF cr > 0
    THEN
      UPDATE customers
      SET credit = credit + cr
      WHERE username = us;
    END IF;
  END;
