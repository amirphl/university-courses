CREATE VIEW store.h1 AS
  (SELECT
     `m0`.`shopId`    AS `shopId`,
     `m0`.`productId` AS `productId`,
     `m0`.`total`     AS `total`
   FROM `store`.`m0`
   WHERE `m0`.`total` >= ALL (SELECT `u`.`total`
                              FROM `store`.`m0` `u`
                              WHERE (`m0`.`shopId` = `u`.`shopId`)));
