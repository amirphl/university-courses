CREATE VIEW store.h4 AS
  (SELECT
     `m3`.`shopId`    AS `shopId`,
     `m3`.`productId` AS `productId`,
     `m3`.`total`     AS `total`
   FROM `store`.`m3`
   WHERE `m3`.`total` >= ALL (SELECT `u`.`total`
                              FROM `store`.`m3` `u`
                              WHERE (`m3`.`shopId` = `u`.`shopId`)));
