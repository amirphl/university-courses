CREATE VIEW store.m1 AS
  (SELECT
     `m0`.`shopId`    AS `shopId`,
     `m0`.`productId` AS `productId`,
     `m0`.`total`     AS `total`
   FROM `store`.`m0`
   WHERE (NOT ((`m0`.`shopId`, `m0`.`productId`, `m0`.`total`) IN (SELECT
                                                                     `h1`.`shopId`,
                                                                     `h1`.`productId`,
                                                                     `h1`.`total`
                                                                   FROM `store`.`h1`))));
