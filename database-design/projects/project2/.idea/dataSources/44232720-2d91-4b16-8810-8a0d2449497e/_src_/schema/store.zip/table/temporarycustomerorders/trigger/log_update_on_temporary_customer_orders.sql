CREATE TRIGGER store.log_update_on_temporary_customer_orders
AFTER UPDATE ON store.temporarycustomerorders
FOR EACH ROW
  BEGIN
    INSERT INTO updatetemporarycustomerorderlog (purchase_time, customerEmail, shopId, productId, pre_status, new_status)
    VALUES (NEW.purchase_time, NEW.customerEmail, NEW.shopId, NEW.productId, OLD.status, NEW.status);
  END;
