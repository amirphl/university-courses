CREATE TRIGGER store.log_update_on_customer_orders
AFTER UPDATE ON store.customerorders
FOR EACH ROW
  BEGIN
    INSERT INTO updatecustomerorderlog (purchase_time, customerUsername, shopId, productId, pre_status, new_status)
    VALUES (NEW.purchase_time, NEW.customerUsername, NEW.shopId, NEW.productId, OLD.status, NEW.status);
  END;
