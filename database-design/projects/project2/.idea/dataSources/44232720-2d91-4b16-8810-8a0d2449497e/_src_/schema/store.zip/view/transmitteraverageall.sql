CREATE VIEW store.transmitteraverageall AS
  (SELECT
     `r`.`id`      AS `id`,
     avg(`r`.`pr`) AS `average`
   FROM (SELECT
           `s`.`transmitterId`         AS `id`,
           (`c`.`value` * `p`.`price`) AS `pr`
         FROM ((`store`.`shipment` `s`
           JOIN `store`.`customerorders` `c` ON ((
             (`s`.`purchase_time` = `c`.`purchase_time`) AND (`s`.`customerUsername` = `c`.`customerUsername`) AND
             (`s`.`shopId` = `c`.`shopId`) AND (`s`.`productId` = `c`.`productId`)))) JOIN `store`.`product` `p`
             ON ((`c`.`productId` = `p`.`id`)))
         UNION ALL SELECT
                     `s`.`transmitterId`         AS `id`,
                     (`c`.`value` * `p`.`price`) AS `pr`
                   FROM ((`store`.`temporaryshipment` `s`
                     JOIN `store`.`temporarycustomerorders` `c` ON ((
                       (`s`.`purchase_time` = `c`.`purchase_time`) AND (`s`.`customerEmail` = `c`.`customerEmail`) AND
                       (`s`.`shopId` = `c`.`shopId`) AND (`s`.`productId` = `c`.`productId`)))) JOIN
                     `store`.`product` `p` ON ((`c`.`productId` = `p`.`id`)))) `r`
   GROUP BY `r`.`id`);
