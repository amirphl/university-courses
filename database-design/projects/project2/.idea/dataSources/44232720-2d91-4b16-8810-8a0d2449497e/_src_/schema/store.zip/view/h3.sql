CREATE VIEW store.h3 AS
  (SELECT
     `m2`.`shopId`    AS `shopId`,
     `m2`.`productId` AS `productId`,
     `m2`.`total`     AS `total`
   FROM `store`.`m2`
   WHERE `m2`.`total` >= ALL (SELECT `u`.`total`
                              FROM `store`.`m2` `u`
                              WHERE (`m2`.`shopId` = `u`.`shopId`)));
