CREATE VIEW store.customersaverage AS
  (SELECT avg((`t`.`value` * `p`.`price`)) AS `average`
   FROM (`store`.`customerorders` `t`
     JOIN `store`.`product` `p` ON (((`t`.`productId` = `p`.`id`) AND (`t`.`shopId` = `p`.`shopId`))))
   WHERE (`t`.`status` <> 'rejected'));
