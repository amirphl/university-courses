CREATE PROCEDURE store.deliver_to_temporary_customer(IN tid INT(10) UNSIGNED, IN pt TIMESTAMP, IN ce VARCHAR(100),
                                                     IN sh  INT(10) UNSIGNED, IN pr INT(10) UNSIGNED)
  BEGIN
    DECLARE state ENUM ('accepted', 'rejected', 'sending', 'done');

    SELECT status
    INTO state
    FROM temporarycustomerorders AS C
    WHERE C.purchase_time = pt AND C.customerEmail = ce AND C.shopId = sh AND C.productId = pr;

    IF state != 'done'
    THEN
      UPDATE temporarycustomerorders AS C
      SET C.status = 'done'
      WHERE C.purchase_time = pt AND C.customerEmail = ce AND C.shopId = sh AND C.productId = pr;

      UPDATE transmitters AS T
      SET T.status = 'free', T.credit = T.credit + 0.05 * (SELECT P.price
                                                           FROM product AS P
                                                           WHERE P.id = pr AND P.shopId = sh)
      WHERE T.id = tid AND T.shopId = sh;
    END IF;
  END;
