CREATE VIEW store.m0 AS
  (SELECT
     `s`.`shopId`     AS `shopId`,
     `s`.`productId`  AS `productId`,
     sum(`s`.`total`) AS `total`
   FROM `store`.`s`
   GROUP BY `s`.`shopId`, `s`.`productId`);
