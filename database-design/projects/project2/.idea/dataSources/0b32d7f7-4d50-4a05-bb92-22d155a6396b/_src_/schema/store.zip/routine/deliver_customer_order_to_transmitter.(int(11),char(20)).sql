CREATE PROCEDURE deliver_customer_order_to_transmitter(IN oid INT, IN sh CHAR(20))
  BEGIN
    SELECT T.id
    INTO @transmitter
    FROM transmitters AS T
    WHERE T.status = 'free' AND T.shopId = sh
    LIMIT 1;

    IF @transmitter IS NULL
    THEN
      UPDATE customerorders AS C
      SET status = 'rejected'
      WHERE C.id = oid;
    ELSE
      UPDATE transmitters AS T
      SET status = 'sending'
      WHERE T.id = @transmitter;

      UPDATE customerorders AS C
      SET status = 'sending'
      WHERE C.id = oid;

      INSERT INTO shipment (transmitterId, orderId) VALUES (@transmitter, oid);
    END IF;
  END;
