CREATE PROCEDURE add_order_by_customer(IN cu VARCHAR(100), IN sh VARCHAR(20), IN pr VARCHAR(20), IN va INT,
                                       IN pa ENUM ('online', 'offline'), IN ad VARCHAR(200), IN ph VARCHAR(14))
  BEGIN

    SELECT @pri := P.price
    FROM product AS P
    WHERE P.shopId = sh AND P.id = pr;

    SELECT @offe := P.offer
    FROM product AS P
    WHERE P.shopId = sh AND P.id = pr;

    SELECT @valu := P.value
    FROM product AS P
    WHERE P.shopId = sh AND P.id = pr;

    SELECT @cu_cred := C.credit
    FROM customers AS C
    WHERE C.username = cu;

    SELECT @shop_start_time := S.start_time
    FROM shop AS S
    WHERE S.id = sh;

    SELECT @shop_end_time := S.end_time
    FROM shop AS S
    WHERE S.id = sh;

    IF @valu < va OR @cu_cred < ((1.0 - @offe) * @pri * va) OR @shop_start_time > current_time OR
       current_time > @shop_end_time
    THEN

      INSERT INTO customerorders (customerUsername, shopId, productId, value, status, payment_type, address, phone_number)
        VALUE (cu, sh, pr, va, 'rejected', pa, ad, ph);

    ELSE

      UPDATE customers AS C
      SET C.credit = C.credit - (1.0 - @offe) * @pri * va
      WHERE C.username = cu AND pa = 'online';

      UPDATE product AS P
      SET P.value = P.value - va
      WHERE P.id = pr AND P.shopId = sh;

      INSERT INTO customerorders (customerUsername, shopId, productId, value, payment_type, address, phone_number)
        VALUE (cu, sh, pr, va, pa, ad, ph);

    END IF;

  END;
