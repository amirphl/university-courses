CREATE PROCEDURE deliver_to_customer(IN oid INT, IN tid CHAR(20))
  BEGIN
    UPDATE customerorders AS C
    SET C.status = 'done'
    WHERE C.id = oid;

    SELECT @pid := productId
    FROM customerorders AS C
    WHERE C.id = oid;

    UPDATE transmitters AS T
    SET T.status = 'free', T.credit = T.credit + 0.05 * (SELECT P.price
                                                         FROM product AS P
                                                         WHERE P.id = @pid)
    WHERE T.id = tid;
  END;
