CREATE TRIGGER after_accept_customer_order
AFTER INSERT ON customerorders
FOR EACH ROW
  BEGIN
    IF NEW.status = 'sending'
    THEN
      SELECT T.id
      INTO @transmitter
      FROM transmitters AS T
      WHERE T.status = 'free' AND T.shopId = NEW.shopId
      LIMIT 1;

      UPDATE transmitters AS T
      SET status = 'sending'
      WHERE T.id = @transmitter;

      INSERT INTO shipment (transmitterId, orderId) VALUES (@transmitter, NEW.id);
    END IF;
  END;
