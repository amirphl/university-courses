CREATE VIEW transmitteraverageall AS
  (SELECT
     `r`.`id`         AS `id`,
     avg(`r`.`total`) AS `average`
   FROM (SELECT
           `transmittersum_1`.`id`    AS `id`,
           `transmittersum_1`.`total` AS `total`
         FROM `onlinestore`.`transmittersum_1`
         UNION ALL SELECT
                     `transmittersum_2`.`id`    AS `id`,
                     `transmittersum_2`.`total` AS `total`
                   FROM `onlinestore`.`transmittersum_2`) `r`
   GROUP BY `r`.`id`);
