CREATE VIEW m0 AS
  (SELECT
     `s`.`shopId`     AS `shopId`,
     `s`.`productId`  AS `productId`,
     sum(`s`.`total`) AS `total`
   FROM `onlinestore`.`s`
   GROUP BY `s`.`shopId`, `s`.`productId`);
