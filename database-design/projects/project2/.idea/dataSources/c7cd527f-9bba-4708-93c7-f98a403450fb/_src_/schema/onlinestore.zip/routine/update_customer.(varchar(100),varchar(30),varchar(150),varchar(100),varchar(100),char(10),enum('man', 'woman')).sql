CREATE PROCEDURE update_customer(IN us VARCHAR(100), IN pa VARCHAR(30), IN em VARCHAR(150), IN fi VARCHAR(100),
                                 IN la VARCHAR(100), IN po CHAR(10), IN ge ENUM ('man', 'woman'))
  BEGIN
    UPDATE customers
    SET password = pa, email = em, first_name = fi, last_name = la, postal_code = po, gender = ge
    WHERE username = us;
  END;
