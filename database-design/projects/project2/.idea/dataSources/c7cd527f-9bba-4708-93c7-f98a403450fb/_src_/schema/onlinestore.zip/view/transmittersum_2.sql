CREATE VIEW transmittersum_2 AS
  (SELECT
     `s`.`transmitterId`              AS `id`,
     sum((`c`.`value` * `p`.`price`)) AS `total`
   FROM ((`onlinestore`.`temporaryshipment` `s`
     JOIN `onlinestore`.`temporarycustomerorders` `c` ON ((`s`.`orderId` = `c`.`id`))) JOIN `onlinestore`.`product` `p`
       ON ((`c`.`productId` = `p`.`id`)))
   GROUP BY `s`.`transmitterId`);
