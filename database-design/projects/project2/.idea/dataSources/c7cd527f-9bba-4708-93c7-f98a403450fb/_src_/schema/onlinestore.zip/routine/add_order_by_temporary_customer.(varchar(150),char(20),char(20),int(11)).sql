CREATE PROCEDURE add_order_by_temporary_customer(IN cu VARCHAR(150), IN sh CHAR(20), IN pr CHAR(20), IN va INT)
  BEGIN
    DECLARE `_rollback` BOOL DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET `_rollback` = 1;
    START TRANSACTION;

    SELECT @valu := P.value
    FROM product AS P
    WHERE P.shopId = sh AND P.id = pr;

    SELECT @shop_start_time := S.start_time
    FROM shop AS S
    WHERE S.id = sh;

    SELECT @shop_end_time := S.end_time
    FROM shop AS S
    WHERE S.id = sh;

    IF @shop_start_time <= current_time AND current_time <= @shop_end_time AND @valu >= va
    THEN
      INSERT INTO temporarycustomerorders (customerEmail, shopId, productId, value)
        VALUE (cu, sh, pr, va);
      UPDATE product AS P
      SET P.value = P.value - va
      WHERE P.id = pr AND P.shopId = sh;
    ELSE
      INSERT INTO temporarycustomerorders (customerEmail, shopId, productId, value, status)
        VALUE (cu, sh, pr, va, 'rejected');
    END IF;

    IF `_rollback`
    THEN
      ROLLBACK;
    ELSE
      COMMIT;
    END IF;
  END;
