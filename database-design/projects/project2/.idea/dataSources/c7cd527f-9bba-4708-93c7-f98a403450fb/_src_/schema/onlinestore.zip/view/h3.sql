CREATE VIEW h3 AS
  (SELECT
     `m2`.`shopId`    AS `shopId`,
     `m2`.`productId` AS `productId`,
     `m2`.`total`     AS `total`
   FROM `onlinestore`.`m2`
   WHERE (`m2`.`total` >= (SELECT `u`.`total`
                           FROM `onlinestore`.`m2` `u`
                           WHERE (`m2`.`shopId` = `u`.`shopId`))));
