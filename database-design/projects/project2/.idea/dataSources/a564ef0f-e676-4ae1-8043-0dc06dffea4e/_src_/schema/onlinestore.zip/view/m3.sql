CREATE VIEW m3 AS
  (SELECT
     `m2`.`shopId`    AS `shopId`,
     `m2`.`productId` AS `productId`,
     `m2`.`total`     AS `total`
   FROM `onlinestore`.`m2`
   WHERE (NOT ((`m2`.`shopId`, `m2`.`productId`, `m2`.`total`) IN (SELECT
                                                                     `h3`.`shopId`,
                                                                     `h3`.`productId`,
                                                                     `h3`.`total`
                                                                   FROM `onlinestore`.`h3`))));
