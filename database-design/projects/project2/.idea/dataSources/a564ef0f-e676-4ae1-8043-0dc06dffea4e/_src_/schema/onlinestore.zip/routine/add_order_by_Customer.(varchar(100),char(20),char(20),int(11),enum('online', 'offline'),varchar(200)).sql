CREATE PROCEDURE add_order_by_Customer(IN cu VARCHAR(100), IN sh CHAR(20), IN pr CHAR(20), IN va INT,
                                       IN pa ENUM ('online', 'offline'), IN ad VARCHAR(200))
  BEGIN
    INSERT INTO customerorders (customerUsername, shopId, productId, value, payment_type, address)
      VALUE (cu, sh, pr, va, pa, ad);
    SELECT @pri := P.price
    FROM product AS P
    WHERE P.shopId = sh AND P.id = pr;
    UPDATE customers AS C
    SET credit = credit - pri
    WHERE C.username = cu AND pa = 'online';
  END;
