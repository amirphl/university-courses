CREATE VIEW transmittersum_1 AS
  (SELECT
     `s`.`transmitterId`              AS `id`,
     sum((`c`.`value` * `p`.`price`)) AS `total`
   FROM ((`onlinestore`.`shipment` `s`
     JOIN `onlinestore`.`customerorders` `c` ON ((`s`.`orderId` = `c`.`id`))) JOIN `onlinestore`.`product` `p`
       ON ((`c`.`productId` = `p`.`id`)))
   GROUP BY `s`.`transmitterId`);
