CREATE VIEW h4 AS
  (SELECT
     `m3`.`shopId`    AS `shopId`,
     `m3`.`productId` AS `productId`,
     `m3`.`total`     AS `total`
   FROM `onlinestore`.`m3`
   WHERE (`m3`.`total` >= (SELECT `u`.`total`
                           FROM `onlinestore`.`m3` `u`
                           WHERE (`m3`.`shopId` = `u`.`shopId`))));
