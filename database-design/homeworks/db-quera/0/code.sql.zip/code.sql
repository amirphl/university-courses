select *
from movie
