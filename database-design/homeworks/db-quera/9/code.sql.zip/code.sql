insert into College VALUES ('Carnegie Mellon' , 'PA' , 11500 )
