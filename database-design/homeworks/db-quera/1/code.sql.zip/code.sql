select title
from Movie
where director = 'Steven Spielberg'
