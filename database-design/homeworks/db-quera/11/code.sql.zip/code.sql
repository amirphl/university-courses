select *
from (
       select
         name,
         title
       from Movie
         NATURAL JOIN Reviewer
         NATURAL JOIN Rating
       where (name, title) not in
             (select
                R.name,
                R.title
              from (select *
                    from Movie
                      NATURAL JOIN Reviewer
                      NATURAL JOIN Rating) as R,
                (select *
                 from Movie
                   NATURAL JOIN Reviewer
                   NATURAL JOIN Rating) as T
              where R.mID = T.mID and R.rID = T.rID and not
              ((R.stars < T.stars and R.ratingDate < T.ratingDate) or
               (R.stars > T.stars and R.ratingDate > T.ratingDate)))
     ) as t2
