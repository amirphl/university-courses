
#include<stdio.h>
#include "stdafx.h"
#include "omp.h"


int main() {




	return 0;
}