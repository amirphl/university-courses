#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void Trap(double a, double b, int n, double *global_result_p);

double Trap_v2(double a, double b, int n);

float fx(float x) {
    return x * x;
}

void integral() {
    printf_s("function integral\n");
    float a = 3.5;
    float b = 11.5;
    int segment = 1000;
    int threads = 4;
    float local_sums[threads];
//    double start_time = omp_get_wtime();
#pragma omp parallel num_threads(threads)
    for (int i = segment * omp_get_thread_num() / threads; i < segment * (omp_get_thread_num() + 1) / threads; ++i) {
        local_sums[omp_get_thread_num()] += fx(a + (b - a) / segment + i * (b - a) / segment);
//        local_sums[omp_get_thread_num()] += (b - a) / segment * fx(a + i * (b - a) / segment);
    }
    float sum = 0;
    for (int j = 0; j < threads; ++j) {
        sum += local_sums[j];
    }
    sum = sum * (b - a) / segment;
//    double end = omp_get_wtime();
    printf_s("result %f:\n", sum);
//    printf_s("time %f:\n", end - start);
}

void integral_v2() {
    printf_s("function integral_v2\n");
    float a = 3.5;
    float b = 11.5;
    int segment = 1000;
    int threads = 4;
    double sum = 0;
//    double start_time = omp_get_wtime();
#pragma omp parallel for num_threads(threads) reduction(+:sum)
    for (int i = 0; i < segment; i++) {
        sum += fx(a + i * (b - a) / segment);
    }
    sum = sum * (b - a) / segment;
//    double end = omp_get_wtime();
    printf_s("result %f:\n", sum);
//    printf_s("time %f:\n", end - start);
}


int main(int argc, char *argv[]) {
    double global_result = 0.0;
    double a = 3.5, b = 11.5;
    int n = 1000;
    int thread_count = 4;

//# pragma omp parallel num_threads(thread_count)
//    Trap(a, b, n, &global_result);

    printf_s("type trap_v2\n");
# pragma omp parallel num_threads(thread_count) reduction(+:global_result)
    global_result += Trap_v2(a, b, n);

    printf("With n = %d trapezoids, our estimation ", n);
    printf("of the integral from %f to %f = %.14enn", a, b, global_result);
    return 0;
} /* main */

void Trap(double a, double b, int n, double *global_result_p) {
    double h, x, my_result;
    double local_a, local_b;
    int i, local_n;
    int my_rank = omp_get_thread_num();
    int thread_count = omp_get_num_threads();

    h = (b - a) / n;
    local_n = n / thread_count;
    local_a = a + my_rank * local_n * h;
    local_b = local_a + local_n * h;
    my_result = (fx(local_a) + fx(local_b)) / 2.0;
    for (i = 1; i <= local_n - 1; i++) {
        x = local_a + i * h;
        my_result += fx(x);
    }
    my_result = my_result * h;

# pragma omp critical
    *global_result_p += my_result;
}

double Trap_v2(double a, double b, int n) {
    double h, x, my_result;
    double local_a, local_b;
    int i, local_n;
    int my_rank = omp_get_thread_num();
    int thread_count = omp_get_num_threads();

    h = (b - a) / n;
    local_n = n / thread_count;
    local_a = a + my_rank * local_n * h;
    local_b = local_a + local_n * h;
    my_result = (fx(local_a) + fx(local_b)) / 2.0;
    for (i = 1; i <= local_n - 1; i++) {
        x = local_a + i * h;
        my_result += fx(x);
    }
    my_result = my_result * h;
    return my_result;
}