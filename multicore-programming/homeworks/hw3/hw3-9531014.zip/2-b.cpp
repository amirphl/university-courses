#include <iostream>
#include <cstdlib>
//#pragma once
using namespace std;

int range0(int a) { if (a > 25) { if (a > 37) { if (a > 43) { return 5; } else { return 4; } } else { return 3; } } else { if (a > 12) { if (a > 18) { return 2; } else { return 1; } } else { return 0; } } }
int range1(int a) { if (a > 75) { if (a > 87) { if (a > 93) { return 6; } else { return 5; } } else { return 4; } } else { if (a > 62) { if (a > 68) { return 3; } else { return 2; } } else { return 1; } } }
int range2(int a) { if (a > 125) { if (a > 137) { if (a > 143) { return 7; } else { return 6; } } else { return 5; } } else { if (a > 112) { if (a > 118) { return 4; } else { return 3; } } else { return 2; } } }
int range3(int a) { if (a > 175) { if (a > 187) { if (a > 193) { return 8; } else { return 7; } } else { return 6; } } else { if (a > 162) { if (a > 168) { return 5; } else { return 4; } } else { return 3; } } }
int range4(int a) { if (a > 225) { if (a > 237) { if (a > 243) { return 9; } else { return 8; } } else { return 7; } } else { if (a > 212) { if (a > 218) { return 6; } else { return 5; } } else { return 4; } } }
int range5(int a) { if (a > 275) { if (a > 287) { if (a > 293) { return 10; } else { return 9; } } else { return 8; } } else { if (a > 262) { if (a > 268) { return 7; } else { return 6; } } else { return 5; } } }
int range6(int a) { if (a > 325) { if (a > 337) { if (a > 343) { return 11; } else { return 10; } } else { return 9; } } else { if (a > 312) { if (a > 318) { return 8; } else { return 7; } } else { return 6; } } }
int range7(int a) { if (a > 375) { if (a > 387) { if (a > 393) { return 12; } else { return 11; } } else { return 10; } } else { if (a > 362) { if (a > 368) { return 9; } else { return 8; } } else { return 7; } } }
int range8(int a) { if (a > 425) { if (a > 437) { if (a > 443) { return 13; } else { return 12; } } else { return 11; } } else { if (a > 412) { if (a > 418) { return 10; } else { return 9; } } else { return 8; } } }
int range9(int a) { if (a > 475) { if (a > 487) { if (a > 493) { return 14; } else { return 13; } } else { return 12; } } else { if (a > 462) { if (a > 468) { return 11; } else { return 10; } } else { return 9; } } }
int range10(int a) { if (a > 525) { if (a > 537) { if (a > 543) { return 15; } else { return 14; } } else { return 13; } } else { if (a > 512) { if (a > 518) { return 12; } else { return 11; } } else { return 10; } } }
int range11(int a) { if (a > 575) { if (a > 587) { if (a > 593) { return 16; } else { return 15; } } else { return 14; } } else { if (a > 562) { if (a > 568) { return 13; } else { return 12; } } else { return 11; } } }
int range12(int a) { if (a > 625) { if (a > 637) { if (a > 643) { return 17; } else { return 16; } } else { return 15; } } else { if (a > 612) { if (a > 618) { return 14; } else { return 13; } } else { return 12; } } }
int range13(int a) { if (a > 675) { if (a > 687) { if (a > 693) { return 18; } else { return 17; } } else { return 16; } } else { if (a > 662) { if (a > 668) { return 15; } else { return 14; } } else { return 13; } } }
int range14(int a) { if (a > 725) { if (a > 737) { if (a > 743) { return 19; } else { return 18; } } else { return 17; } } else { if (a > 712) { if (a > 718) { return 16; } else { return 15; } } else { return 14; } } }
int range15(int a) { if (a > 775) { if (a > 787) { if (a > 793) { return 20; } else { return 19; } } else { return 18; } } else { if (a > 762) { if (a > 768) { return 17; } else { return 16; } } else { return 15; } } }
int range16(int a) { if (a > 825) { if (a > 837) { if (a > 843) { return 21; } else { return 20; } } else { return 19; } } else { if (a > 812) { if (a > 818) { return 18; } else { return 17; } } else { return 16; } } }
int range17(int a) { if (a > 875) { if (a > 887) { if (a > 893) { return 22; } else { return 21; } } else { return 20; } } else { if (a > 862) { if (a > 868) { return 19; } else { return 18; } } else { return 17; } } }
int range18(int a) { if (a > 925) { if (a > 937) { if (a > 943) { return 23; } else { return 22; } } else { return 21; } } else { if (a > 912) { if (a > 918) { return 20; } else { return 19; } } else { return 18; } } }
int range19(int a) { if (a > 975) { if (a > 987) { if (a > 993) { return 24; } else { return 23; } } else { return 22; } } else { if (a > 962) { if (a > 968) { return 21; } else { return 20; } } else { return 19; } } }
int range20(int a) { if (a > 1025) { if (a > 1037) { if (a > 1043) { return 25; } else { return 24; } } else { return 23; } } else { if (a > 1012) { if (a > 1018) { return 22; } else { return 21; } } else { return 20; } } }
int range21(int a) { if (a > 1075) { if (a > 1087) { if (a > 1093) { return 26; } else { return 25; } } else { return 24; } } else { if (a > 1062) { if (a > 1068) { return 23; } else { return 22; } } else { return 21; } } }
int range22(int a) { if (a > 1125) { if (a > 1137) { if (a > 1143) { return 27; } else { return 26; } } else { return 25; } } else { if (a > 1112) { if (a > 1118) { return 24; } else { return 23; } } else { return 22; } } }
int range23(int a) { if (a > 1175) { if (a > 1187) { if (a > 1193) { return 28; } else { return 27; } } else { return 26; } } else { if (a > 1162) { if (a > 1168) { return 25; } else { return 24; } } else { return 23; } } }
int range24(int a) { if (a > 1225) { if (a > 1237) { if (a > 1243) { return 29; } else { return 28; } } else { return 27; } } else { if (a > 1212) { if (a > 1218) { return 26; } else { return 25; } } else { return 24; } } }
int range25(int a) { if (a > 1275) { if (a > 1287) { if (a > 1293) { return 30; } else { return 29; } } else { return 28; } } else { if (a > 1262) { if (a > 1268) { return 27; } else { return 26; } } else { return 25; } } }
int range26(int a) { if (a > 1325) { if (a > 1337) { if (a > 1343) { return 31; } else { return 30; } } else { return 29; } } else { if (a > 1312) { if (a > 1318) { return 28; } else { return 27; } } else { return 26; } } }
int range27(int a) { if (a > 1375) { if (a > 1387) { if (a > 1393) { return 32; } else { return 31; } } else { return 30; } } else { if (a > 1362) { if (a > 1368) { return 29; } else { return 28; } } else { return 27; } } }
int range28(int a) { if (a > 1425) { if (a > 1437) { if (a > 1443) { return 33; } else { return 32; } } else { return 31; } } else { if (a > 1412) { if (a > 1418) { return 30; } else { return 29; } } else { return 28; } } }
int range29(int a) { if (a > 1475) { if (a > 1487) { if (a > 1493) { return 34; } else { return 33; } } else { return 32; } } else { if (a > 1462) { if (a > 1468) { return 31; } else { return 30; } } else { return 29; } } }
int range30(int a) { if (a > 1525) { if (a > 1537) { if (a > 1543) { return 35; } else { return 34; } } else { return 33; } } else { if (a > 1512) { if (a > 1518) { return 32; } else { return 31; } } else { return 30; } } }
int range31(int a) { if (a > 1575) { if (a > 1587) { if (a > 1593) { return 36; } else { return 35; } } else { return 34; } } else { if (a > 1562) { if (a > 1568) { return 33; } else { return 32; } } else { return 31; } } }
int range32(int a) { if (a > 1625) { if (a > 1637) { if (a > 1643) { return 37; } else { return 36; } } else { return 35; } } else { if (a > 1612) { if (a > 1618) { return 34; } else { return 33; } } else { return 32; } } }
int range33(int a) { if (a > 1675) { if (a > 1687) { if (a > 1693) { return 38; } else { return 37; } } else { return 36; } } else { if (a > 1662) { if (a > 1668) { return 35; } else { return 34; } } else { return 33; } } }
int range34(int a) { if (a > 1725) { if (a > 1737) { if (a > 1743) { return 39; } else { return 38; } } else { return 37; } } else { if (a > 1712) { if (a > 1718) { return 36; } else { return 35; } } else { return 34; } } }
int range35(int a) { if (a > 1775) { if (a > 1787) { if (a > 1793) { return 40; } else { return 39; } } else { return 38; } } else { if (a > 1762) { if (a > 1768) { return 37; } else { return 36; } } else { return 35; } } }
int range36(int a) { if (a > 1825) { if (a > 1837) { if (a > 1843) { return 41; } else { return 40; } } else { return 39; } } else { if (a > 1812) { if (a > 1818) { return 38; } else { return 37; } } else { return 36; } } }
int range37(int a) { if (a > 1875) { if (a > 1887) { if (a > 1893) { return 42; } else { return 41; } } else { return 40; } } else { if (a > 1862) { if (a > 1868) { return 39; } else { return 38; } } else { return 37; } } }
int range38(int a) { if (a > 1925) { if (a > 1937) { if (a > 1943) { return 43; } else { return 42; } } else { return 41; } } else { if (a > 1912) { if (a > 1918) { return 40; } else { return 39; } } else { return 38; } } }
int range39(int a) { if (a > 1975) { if (a > 1987) { if (a > 1993) { return 44; } else { return 43; } } else { return 42; } } else { if (a > 1962) { if (a > 1968) { return 41; } else { return 40; } } else { return 39; } } }
int range40(int a) { if (a > 2025) { if (a > 2037) { if (a > 2043) { return 45; } else { return 44; } } else { return 43; } } else { if (a > 2012) { if (a > 2018) { return 42; } else { return 41; } } else { return 40; } } }
int range41(int a) { if (a > 2075) { if (a > 2087) { if (a > 2093) { return 46; } else { return 45; } } else { return 44; } } else { if (a > 2062) { if (a > 2068) { return 43; } else { return 42; } } else { return 41; } } }
int range42(int a) { if (a > 2125) { if (a > 2137) { if (a > 2143) { return 47; } else { return 46; } } else { return 45; } } else { if (a > 2112) { if (a > 2118) { return 44; } else { return 43; } } else { return 42; } } }
int range43(int a) { if (a > 2175) { if (a > 2187) { if (a > 2193) { return 48; } else { return 47; } } else { return 46; } } else { if (a > 2162) { if (a > 2168) { return 45; } else { return 44; } } else { return 43; } } }
int range44(int a) { if (a > 2225) { if (a > 2237) { if (a > 2243) { return 49; } else { return 48; } } else { return 47; } } else { if (a > 2212) { if (a > 2218) { return 46; } else { return 45; } } else { return 44; } } }
int range45(int a) { if (a > 2275) { if (a > 2287) { if (a > 2293) { return 50; } else { return 49; } } else { return 48; } } else { if (a > 2262) { if (a > 2268) { return 47; } else { return 46; } } else { return 45; } } }
int range46(int a) { if (a > 2325) { if (a > 2337) { if (a > 2343) { return 51; } else { return 50; } } else { return 49; } } else { if (a > 2312) { if (a > 2318) { return 48; } else { return 47; } } else { return 46; } } }
int range47(int a) { if (a > 2375) { if (a > 2387) { if (a > 2393) { return 52; } else { return 51; } } else { return 50; } } else { if (a > 2362) { if (a > 2368) { return 49; } else { return 48; } } else { return 47; } } }
int range48(int a) { if (a > 2425) { if (a > 2437) { if (a > 2443) { return 53; } else { return 52; } } else { return 51; } } else { if (a > 2412) { if (a > 2418) { return 50; } else { return 49; } } else { return 48; } } }
int range49(int a) { if (a > 2475) { if (a > 2487) { if (a > 2493) { return 54; } else { return 53; } } else { return 52; } } else { if (a > 2462) { if (a > 2468) { return 51; } else { return 50; } } else { return 49; } } }
int range50(int a) { if (a > 2525) { if (a > 2537) { if (a > 2543) { return 55; } else { return 54; } } else { return 53; } } else { if (a > 2512) { if (a > 2518) { return 52; } else { return 51; } } else { return 50; } } }
int range51(int a) { if (a > 2575) { if (a > 2587) { if (a > 2593) { return 56; } else { return 55; } } else { return 54; } } else { if (a > 2562) { if (a > 2568) { return 53; } else { return 52; } } else { return 51; } } }
int range52(int a) { if (a > 2625) { if (a > 2637) { if (a > 2643) { return 57; } else { return 56; } } else { return 55; } } else { if (a > 2612) { if (a > 2618) { return 54; } else { return 53; } } else { return 52; } } }
int range53(int a) { if (a > 2675) { if (a > 2687) { if (a > 2693) { return 58; } else { return 57; } } else { return 56; } } else { if (a > 2662) { if (a > 2668) { return 55; } else { return 54; } } else { return 53; } } }
int range54(int a) { if (a > 2725) { if (a > 2737) { if (a > 2743) { return 59; } else { return 58; } } else { return 57; } } else { if (a > 2712) { if (a > 2718) { return 56; } else { return 55; } } else { return 54; } } }
int range55(int a) { if (a > 2775) { if (a > 2787) { if (a > 2793) { return 60; } else { return 59; } } else { return 58; } } else { if (a > 2762) { if (a > 2768) { return 57; } else { return 56; } } else { return 55; } } }
int range56(int a) { if (a > 2825) { if (a > 2837) { if (a > 2843) { return 61; } else { return 60; } } else { return 59; } } else { if (a > 2812) { if (a > 2818) { return 58; } else { return 57; } } else { return 56; } } }
int range57(int a) { if (a > 2875) { if (a > 2887) { if (a > 2893) { return 62; } else { return 61; } } else { return 60; } } else { if (a > 2862) { if (a > 2868) { return 59; } else { return 58; } } else { return 57; } } }
int range58(int a) { if (a > 2925) { if (a > 2937) { if (a > 2943) { return 63; } else { return 62; } } else { return 61; } } else { if (a > 2912) { if (a > 2918) { return 60; } else { return 59; } } else { return 58; } } }
int range59(int a) { if (a > 2975) { if (a > 2987) { if (a > 2993) { return 64; } else { return 63; } } else { return 62; } } else { if (a > 2962) { if (a > 2968) { return 61; } else { return 60; } } else { return 59; } } }
int range60(int a) { if (a > 3025) { if (a > 3037) { if (a > 3043) { return 65; } else { return 64; } } else { return 63; } } else { if (a > 3012) { if (a > 3018) { return 62; } else { return 61; } } else { return 60; } } }
int range61(int a) { if (a > 3075) { if (a > 3087) { if (a > 3093) { return 66; } else { return 65; } } else { return 64; } } else { if (a > 3062) { if (a > 3068) { return 63; } else { return 62; } } else { return 61; } } }
int range62(int a) { if (a > 3125) { if (a > 3137) { if (a > 3143) { return 67; } else { return 66; } } else { return 65; } } else { if (a > 3112) { if (a > 3118) { return 64; } else { return 63; } } else { return 62; } } }
int range63(int a) { if (a > 3175) { if (a > 3187) { if (a > 3193) { return 68; } else { return 67; } } else { return 66; } } else { if (a > 3162) { if (a > 3168) { return 65; } else { return 64; } } else { return 63; } } }
int range64(int a) { if (a > 3225) { if (a > 3237) { if (a > 3243) { return 69; } else { return 68; } } else { return 67; } } else { if (a > 3212) { if (a > 3218) { return 66; } else { return 65; } } else { return 64; } } }
int range65(int a) { if (a > 3275) { if (a > 3287) { if (a > 3293) { return 70; } else { return 69; } } else { return 68; } } else { if (a > 3262) { if (a > 3268) { return 67; } else { return 66; } } else { return 65; } } }
int range66(int a) { if (a > 3325) { if (a > 3337) { if (a > 3343) { return 71; } else { return 70; } } else { return 69; } } else { if (a > 3312) { if (a > 3318) { return 68; } else { return 67; } } else { return 66; } } }
int range67(int a) { if (a > 3375) { if (a > 3387) { if (a > 3393) { return 72; } else { return 71; } } else { return 70; } } else { if (a > 3362) { if (a > 3368) { return 69; } else { return 68; } } else { return 67; } } }
int range68(int a) { if (a > 3425) { if (a > 3437) { if (a > 3443) { return 73; } else { return 72; } } else { return 71; } } else { if (a > 3412) { if (a > 3418) { return 70; } else { return 69; } } else { return 68; } } }
int range69(int a) { if (a > 3475) { if (a > 3487) { if (a > 3493) { return 74; } else { return 73; } } else { return 72; } } else { if (a > 3462) { if (a > 3468) { return 71; } else { return 70; } } else { return 69; } } }
int range70(int a) { if (a > 3525) { if (a > 3537) { if (a > 3543) { return 75; } else { return 74; } } else { return 73; } } else { if (a > 3512) { if (a > 3518) { return 72; } else { return 71; } } else { return 70; } } }
int range71(int a) { if (a > 3575) { if (a > 3587) { if (a > 3593) { return 76; } else { return 75; } } else { return 74; } } else { if (a > 3562) { if (a > 3568) { return 73; } else { return 72; } } else { return 71; } } }
int range72(int a) { if (a > 3625) { if (a > 3637) { if (a > 3643) { return 77; } else { return 76; } } else { return 75; } } else { if (a > 3612) { if (a > 3618) { return 74; } else { return 73; } } else { return 72; } } }
int range73(int a) { if (a > 3675) { if (a > 3687) { if (a > 3693) { return 78; } else { return 77; } } else { return 76; } } else { if (a > 3662) { if (a > 3668) { return 75; } else { return 74; } } else { return 73; } } }
int range74(int a) { if (a > 3725) { if (a > 3737) { if (a > 3743) { return 79; } else { return 78; } } else { return 77; } } else { if (a > 3712) { if (a > 3718) { return 76; } else { return 75; } } else { return 74; } } }
int range75(int a) { if (a > 3775) { if (a > 3787) { if (a > 3793) { return 80; } else { return 79; } } else { return 78; } } else { if (a > 3762) { if (a > 3768) { return 77; } else { return 76; } } else { return 75; } } }
int range76(int a) { if (a > 3825) { if (a > 3837) { if (a > 3843) { return 81; } else { return 80; } } else { return 79; } } else { if (a > 3812) { if (a > 3818) { return 78; } else { return 77; } } else { return 76; } } }
int range77(int a) { if (a > 3875) { if (a > 3887) { if (a > 3893) { return 82; } else { return 81; } } else { return 80; } } else { if (a > 3862) { if (a > 3868) { return 79; } else { return 78; } } else { return 77; } } }
int range78(int a) { if (a > 3925) { if (a > 3937) { if (a > 3943) { return 83; } else { return 82; } } else { return 81; } } else { if (a > 3912) { if (a > 3918) { return 80; } else { return 79; } } else { return 78; } } }
int range79(int a) { if (a > 3975) { if (a > 3987) { if (a > 3993) { return 84; } else { return 83; } } else { return 82; } } else { if (a > 3962) { if (a > 3968) { return 81; } else { return 80; } } else { return 79; } } }
int categorize(int a)
{
	int range = 85;
	if (a < 50 && a>0) { range = range0(a); }
	if (a < 100 && a>50) { range = range1(a); }
	if (a < 150 && a>100) { range = range2(a); }
	if (a < 200 && a>150) { range = range3(a); }
	if (a < 250 && a>200) { range = range4(a); }
	if (a < 300 && a>250) { range = range5(a); }
	if (a < 350 && a>300) { range = range6(a); }
	if (a < 400 && a>350) { range = range7(a); }
	if (a < 450 && a>400) { range = range8(a); }
	if (a < 500 && a>450) { range = range9(a); }
	if (a < 550 && a>500) { range = range10(a); }
	if (a < 600 && a>550) { range = range11(a); }
	if (a < 650 && a>600) { range = range12(a); }
	if (a < 700 && a>650) { range = range13(a); }
	if (a < 750 && a>700) { range = range14(a); }
	if (a < 800 && a>750) { range = range15(a); }
	if (a < 850 && a>800) { range = range16(a); }
	if (a < 900 && a>850) { range = range17(a); }
	if (a < 950 && a>900) { range = range18(a); }
	if (a < 1000 && a>950) { range = range19(a); }
	if (a < 1050 && a>1000) { range = range20(a); }
	if (a < 1100 && a>1050) { range = range21(a); }
	if (a < 1150 && a>1100) { range = range22(a); }
	if (a < 1200 && a>1150) { range = range23(a); }
	if (a < 1250 && a>1200) { range = range24(a); }
	if (a < 1300 && a>1250) { range = range25(a); }
	if (a < 1350 && a>1300) { range = range26(a); }
	if (a < 1400 && a>1350) { range = range27(a); }
	if (a < 1450 && a>1400) { range = range28(a); }
	if (a < 1500 && a>1450) { range = range29(a); }
	if (a < 1550 && a>1500) { range = range30(a); }
	if (a < 1600 && a>1550) { range = range31(a); }
	if (a < 1650 && a>1600) { range = range32(a); }
	if (a < 1700 && a>1650) { range = range33(a); }
	if (a < 1750 && a>1700) { range = range34(a); }
	if (a < 1800 && a>1750) { range = range35(a); }
	if (a < 1850 && a>1800) { range = range36(a); }
	if (a < 1900 && a>1850) { range = range37(a); }
	if (a < 1950 && a>1900) { range = range38(a); }
	if (a < 2000 && a>1950) { range = range39(a); }
	if (a < 2050 && a>2000) { range = range40(a); }
	if (a < 2100 && a>2050) { range = range41(a); }
	if (a < 2150 && a>2100) { range = range42(a); }
	if (a < 2200 && a>2150) { range = range43(a); }
	if (a < 2250 && a>2200) { range = range44(a); }
	if (a < 2300 && a>2250) { range = range45(a); }
	if (a < 2350 && a>2300) { range = range46(a); }
	if (a < 2400 && a>2350) { range = range47(a); }
	if (a < 2450 && a>2400) { range = range48(a); }
	if (a < 2500 && a>2450) { range = range49(a); }
	if (a < 2550 && a>2500) { range = range50(a); }
	if (a < 2600 && a>2550) { range = range51(a); }
	if (a < 2650 && a>2600) { range = range52(a); }
	if (a < 2700 && a>2650) { range = range53(a); }
	if (a < 2750 && a>2700) { range = range54(a); }
	if (a < 2800 && a>2750) { range = range55(a); }
	if (a < 2850 && a>2800) { range = range56(a); }
	if (a < 2900 && a>2850) { range = range57(a); }
	if (a < 2950 && a>2900) { range = range58(a); }
	if (a < 3000 && a>2950) { range = range59(a); }
	if (a < 3050 && a>3000) { range = range60(a); }
	if (a < 3100 && a>3050) { range = range61(a); }
	if (a < 3150 && a>3100) { range = range62(a); }
	if (a < 3200 && a>3150) { range = range63(a); }
	if (a < 3250 && a>3200) { range = range64(a); }
	if (a < 3300 && a>3250) { range = range65(a); }
	if (a < 3350 && a>3300) { range = range66(a); }
	if (a < 3400 && a>3350) { range = range67(a); }
	if (a < 3450 && a>3400) { range = range68(a); }
	if (a < 3500 && a>3450) { range = range69(a); }
	if (a < 3550 && a>3500) { range = range70(a); }
	if (a < 3600 && a>3550) { range = range71(a); }
	if (a < 3650 && a>3600) { range = range72(a); }
	if (a < 3700 && a>3650) { range = range73(a); }
	if (a < 3750 && a>3700) { range = range74(a); }
	if (a < 3800 && a>3750) { range = range75(a); }
	if (a < 3850 && a>3800) { range = range76(a); }
	if (a < 3900 && a>3850) { range = range77(a); }
	if (a < 3950 && a>3900) { range = range78(a); }
	if (a < 4000 && a>3950) { range = range79(a); }
	return range;
}

const int size = 7000000;
const int range = 4000;
const int cluster_size = 85 + 1;
int *array;
int *clusters; 

void print(){
	int s = 0;
	for (int j = 0;j<cluster_size;j++)
	{
		printf("cluster %d contains %d numbers.\n",j,clusters[j]);
		s += clusters[j];
	}
	
	if(s != size)
		printf("s = %d , size = %d . something is wrong..." , s , size);
}

int main()
{	
	
	array = (int *)malloc(size * sizeof(int));
	clusters = (int *)malloc(cluster_size * sizeof(int));
	
	for (int j = 0;j<size;j++)
	{
		array[j] = j % range;
	}
	
	for (int j = 0;j<cluster_size;j++)
	{
		clusters[j] = 0;
	}

	int index;
	for (int j = 0;j<size;j++)
	{
		index = categorize(array[j]);
		clusters[index]++;
	}
	
	print();
	
	return 0;
}